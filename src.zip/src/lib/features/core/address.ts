import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const axiosInstance = axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_URL,
    headers: {
        'Content-Type': 'application/json',
        "Api-Secret": 'kTbQiA3EJk1ZXR',
        Authorization: `Bearer ${typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('token') : ''}`,

    },
});

// Fetch countries
export const fetchCountries = createAsyncThunk('address/fetchCountries', async () => {
    const response = await axiosInstance.get('address/countries?locale=en');
    return response.data.result.data;
});

// Fetch cities
export const fetchCities = createAsyncThunk('address/fetchCities', async (countryId:number) => {
    const response = await axiosInstance.get(`address/cities?country_id=${countryId}`);
    return response.data.result.data;
});

// Fetch municipalities
export const fetchMunicipalities = createAsyncThunk(
    'address/fetchMunicipalities',
    async (cityId:number) => {
        const response = await axiosInstance.get(`address/municipalities?city_id=${cityId}`);
        return response.data.result.data;
    }
);
// ne
export const fetchNeighborhoods = createAsyncThunk(
    'address/neighborhoods',
    async (municipalityId:number) => {
        const response = await axiosInstance.get(`address/neighborhoods?municipality_id=${municipalityId}`);
        return response.data.result.data;
    }
);
type State = {
    countries: {
        data: any;
        status: 'idle' | 'loading' | 'succeeded' | 'failed';
        error: string | null | undefined;
    };
    cities: {
        data: any;
        status: 'idle' | 'loading' | 'succeeded' | 'failed';
        error: string | null | undefined;
    };
    municipalities: {
        data: any;
        status: 'idle' | 'loading' | 'succeeded' | 'failed';
        error: string | null | undefined;
    };
    neighborhoods: {
        data: any;
        status: 'idle' | 'loading' | 'succeeded' | 'failed';
        error: string | null | undefined;
    };
};
const addressSlice = createSlice({
    name: 'address',
    initialState: {
        countries: {
            data: [],
            status: 'idle',
            error: null,
        },
        cities: {
            data: [],
            status: 'idle',
            error: null,
        },
        municipalities: {
            data: [],
            status: 'idle',
            error: null,
        },
        neighborhoods: {
            data: [],
            status: 'idle',
            error: null,
        },
    } as State,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchCountries.pending, (state) => {
                state.countries.status = 'loading';
            })
            .addCase(fetchCountries.fulfilled, (state, action) => {
                state.countries = action.payload;
              })
            .addCase(fetchCountries.rejected, (state, action) => {
                state.countries.status = 'failed';
                state.countries.error = action.error.message;
            })
            .addCase(fetchCities.pending, (state) => {
                state.cities.status = 'loading';
            })
            .addCase(fetchCities.fulfilled, (state, action) => {
                state.cities.status = 'succeeded';
                state.cities.data = action.payload;
            })
            .addCase(fetchCities.rejected, (state, action) => {
                state.cities.status = 'failed';
                state.cities.error = action.error.message;
            })
            .addCase(fetchMunicipalities.pending, (state) => {
                state.municipalities.status = 'loading';
            })
            .addCase(fetchMunicipalities.fulfilled, (state, action) => {
                state.municipalities.status = 'succeeded';
                state.municipalities.data = action.payload;
            })
            .addCase(fetchMunicipalities.rejected, (state, action) => {
                state.municipalities.status = 'failed';
                state.municipalities.error = action.error.message;
            })
            .addCase(fetchNeighborhoods.pending, (state) => {
                state.neighborhoods.status = 'loading';
            })
            .addCase(fetchNeighborhoods.fulfilled, (state, action) => {
                state.neighborhoods.status = 'succeeded';
                state.neighborhoods.data = action.payload;
            })
            .addCase(fetchNeighborhoods.rejected, (state, action) => {
                state.neighborhoods.status = 'failed';
                state.neighborhoods.error = action.error.message;
            });

    },
});

export default addressSlice.reducer;
