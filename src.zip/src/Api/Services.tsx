import axios from "axios";
import { handleError, handleResponse } from "./handleresponse";
import {objectToQueryString} from './handleresponse'
const createAxiosInstance = (contentType: string) => {
  const headers = {
    "Content-Type": contentType,
    "Api-Secret": 'kTbQiA3EJk1ZXR',
    Authorization: `Bearer ${
      typeof window !== "undefined" && window.localStorage
        ? localStorage.getItem("token")
        : ""
    }`,
  };

  return axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_URL,
    headers,
  });
};

const api = createAxiosInstance("application/json");
const apiFormData = createAxiosInstance("multipart/form-data");

api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.log(error.response)
    if (error.response && error.response.status === 401) {
      authLogout();
    }
    return Promise.reject(error);
  }
);

export const authRegister = async (registerData: any) => {
  try {
    const response = await api.post("auth/register", registerData);
    return handleResponse(response, "");
  } catch (error) {
    handleError(error);
  }
};

export const otpVerfiy = async (otpVerifyData: any) => {
  try {
    const response = await api.post("auth/otp-verify", otpVerifyData);
    return handleResponse(response, "");
  } catch (error) {
    handleError(error);
  }
};

export const authLogin = async (loginData: any) => {
  try {
    const response = await api.post("auth/login", loginData);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const authLogout = async () => {
  try {
    const response = await api.post("auth/logout");
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const forgotPassword = async (email: any) => {
  try {
    const response = await api.post("auth/forgot_password", email);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const resetPassword = async (resetData: any) => {
  try {
    const response = await api.post("auth/reset_password", resetData);
    return handleResponse(response, "Post");
  } catch (error) {
    console.log('error')
    handleError(error);
  }
};

export const editUser = async (editUserData: any) => {
  try {
    const response = await apiFormData.post("user/edit", editUserData);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const deleteUser = async () => {
  try {
    const response = await api.delete("user/send_a_delete_request");
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
  return;
};

export const userInfo = async () => {
  try {
    const response = await api.get("user/info");
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};
export const getCountries = async () => {
  try {
    const response = await api.get("address/countries");
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const getCities = async (country_id: number) => {
  try {
    const response = await api.get(`address/cities?country_id=${country_id}`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const getMnicipalities = async (city_id: number) => {
  try {
    const response = await api.get(`address/municipalities?city_id=${city_id}`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const getNeighborhoods = async (municipality_id: number) => {
  try {
    const response = await api.get(
      `address/neighborhoods?municipality_id=${municipality_id}`
    );
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const getProductList = async (
  page?: number,
  search?: string,
  filter?: {}
) => {
  try {
    if (search !== undefined) {
    const response = await api.get(
      `product/list?page=${page}&search=${search}&${filter}`);
      return handleResponse(response, "search");
    }
    else if (filter !== undefined) {
      let queryString = objectToQueryString(filter);
      const response = await api.get(
        `product/list?page=${page}&${queryString}`
      );
      return handleResponse(response, "filter");
    } else {
      const response = await api.get(`product/list?page=${page}`);
      return handleResponse(response, "products");
    }
  } catch (error) {
    handleError(error);
  }
};

export const createProduct = async (productData: any) => {
  try {
    const response = await apiFormData.post("product/store", productData);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const updateProduct = async (productId: any, productData: any) => {
  try {
    const response = await apiFormData.post(
      `product/update/${productId}`,
      productData
    );
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const deleteProduct = async (productId: number) => {
  try {
    const response = await api.delete(`product/delete?product_id=${productId}`);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};
export const showProduct = async (productId: any) => {
  try {
    const response = await api.get(`product/show?product_id=${productId}`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};
export const UpdateXMLProduct = async (Xml: any) => {
  try {
    const response = await api.post(
      `product/update-products-from-xml-url`,
      Xml
    );
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};
export const ImportProducts = async (data: any) => {
  try {
    const response = await apiFormData.post(`product/import-products`, data);
    return handleResponse(response, "" , "Message");
  } catch (error) {
    handleError(error);
  }
};
export const getCategories = async () => {
  try {
    const response = await api.get("definitions/categories");
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const getAttributes = async () => {
  try {
    const response = await api.get("definitions/attributes");
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const getOrder = async () => {
  try {
    const response = await api.get("order/list");
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const showOrder = async (orderCode: any) => {
  try {
    const response = await api.get(`order/show?order_code=${orderCode}`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const changeOrderStatus = async (orderData: any) => {
  try {
    const response = await api.post(`order/change_items_status`, orderData);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const getComplaint = async () => {
  try {
    const response = await api.get(`complaint/list`);
    return handleResponse(response, "");
  } catch (error) {
    handleError(error);
  }
};

export const getComplaintDefinitions = async () => {
  try {
    const response = await api.get(`complaint/definitions`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const createComplaint = async (complaintData: any) => {
  try {
    const response = await apiFormData.post(`complaint/create`, complaintData);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};
export const UpdateComplaint = async (
  complaintId: number,
  complaintData: any
) => {
  try {
    const response = await apiFormData.post(
      `complaint/update/${complaintId}`,
      complaintData
    );
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const BanksInfo = async () => {
  try {
    const response = await api.get(`bank_account/list`);
    return handleResponse(response, "banks");
  } catch (error) {
    handleError(error);
  }
};

export const CreateBankAccount = async (BankInfo: any) => {
  try {
    const response = await api.post(`bank_account/create`, BankInfo);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const DetailsBankAccount = async (BankId: number) => {
  try {
    const response = await api.get(`bank_account/show/${BankId}`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const UpdateBankAccount = async (BankInfo: any, BankId: any) => {
  try {
    const response = await api.post(`bank_account/update/${BankId}`, BankInfo);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const DeleteBankAccount = async (BankId: number) => {
  try {
    const response = await api.delete(`bank_account/delete/${BankId}`);
    return handleResponse(response, "Delete");
  } catch (error) {
    handleError(error);
  }
};

export const CurrencySystem = async () => {
  try {
    const response = await api.get(`system/currencies_supports_in_system`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const EmployeeInfo = async () => {
  try {
    const response = await api.get(`employee/list`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const AddEmployee = async (EmployeeInfo: any) => {
  try {
    const response = await api.post(`employee/create`, EmployeeInfo);
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const DetailsEmployee = async (EmployeeId: number) => {
  try {
    const response = await api.get(`employee/show/${EmployeeId}`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const UpdateEmployee = async (EmployeeInfo: any, EmplyeeId: any) => {
  try {
    const response = await api.post(
      `employee/update/${EmplyeeId}`,
      EmployeeInfo
    );
    return handleResponse(response, "Post");
  } catch (error) {
    handleError(error);
  }
};

export const DeleteEmplyee = async (EmplyeeId: number) => {
  try {
    const response = await api.delete(`employee/delete/${EmplyeeId}`);
    return handleResponse(response, "Delete");
  } catch (error) {
    handleError(error);
  }
};

export const Roles = async () => {
  try {
    const response = await api.get(`employee/list_of_roles_to_employee`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const Notifications = async () => {
  try {
    const response = await api.get(`notification/list`);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const MarkNotifications = async (notification_id:any) => {
  try {
    const response = await api.post(`notification/mark_as_read` , notification_id);
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export const getAnalytics = async () => {
  try {
    const response = await api.get("/analysis");
    return handleResponse(response);
  } catch (error) {
    handleError(error);
  }
};

export default api;
