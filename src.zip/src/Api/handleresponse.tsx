import { Bounce, toast } from "react-toastify";
import { authLogout } from "./Services";

export const handleResponse = (
  response: any,
  requestType?: string,
  message?: string
) => {
  if (response === undefined) {
    handleError(response.response.data.errors);
  }
  if (response.status === 200) {
    if (requestType === "Post" || requestType === "Delete" || message === "Message") {
        handleSuccess(response?.data);
    }
    const result = response.data.result;
    if (requestType === "Post" || requestType === "Delete") {
      window.location?.replace(window.location?.href);
    }
    if (Array.isArray(result) && result.length > 0) {
      return result;
    } else if (typeof result === "object" && !Array.isArray(result) && result) {

        return result;
    }
  } else {
    handleError(response.errors);
  }
};

export const handleError = async (error: any) => {
  if (error.response.status === 401) {
    localStorage.clear();
    await authLogout();
    window.location.href = "/login";
  }
  else{
    toast(error.response.data.errors[0], {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      theme: "dark",
      transition: Bounce,
    });
  }
 
};

export const handleSuccess = (response: any) => {
  const message = response.message
  ? response.message
  : "The process was completed successfully";
  toast(message, {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    theme: "light",
    transition: Bounce,
    style: { backgroundColor: "#caf1d8", color: "#1da750" },
  });
};

export function objectToQueryString(obj:any) {
  const keyValuePairs = [];
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const value = obj[key];
      if (Array.isArray(value)) {
        keyValuePairs.push(
          encodeURIComponent(key) +
            "=" +
            encodeURIComponent(JSON.stringify(value))
        );
      } else {
        keyValuePairs.push(
          encodeURIComponent(key) + "=" + encodeURIComponent(value)
        );
      }
    }
  }
  return keyValuePairs.join("&");
}