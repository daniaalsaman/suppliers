"use client"
import Pusher from 'pusher-js';
import { Bounce, ToastContainer, toast } from 'react-toastify';

const PrivateChannelComponent = () => {

  if (typeof window !== 'undefined' && window.localStorage) {
      const access_token = localStorage.getItem('token');
      const user = JSON.parse(localStorage.getItem('User') || '{}');

      if(access_token && user.id){
          const pusher = new Pusher('bd5863ae5af0484c7a84', {
              cluster: 'ap1',
              authEndpoint:`https://doshtu-app.com/api/v1/suppliers/socket/auth/check`,
              auth: {
                headers: {
                 Authorization: "Bearer " + access_token,
                 'Api-Secret': 'kTbQiA3EJk1ZXR',
                }
              },
          });

          const channel = pusher.subscribe(`private-supplier.${user.id}`);

          const handleNotification = (data: any) => {
            if (data.data && data.data.title) {
              const title = data.data.title;
              const description = data.data.description || '';
              toast(`${title}: ${description}`  , {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                theme: data.data.notifyType == 'success' ? "light" : "dark",
                transition: Bounce,
                style: { backgroundColor: "#caf1d8", color: "#1da750" },
              });

            } else {
              console.error("Invalid notification data format:", data);
            }
          };

          channel.bind('broad-cast-supplier', handleNotification);

          return () => {
            channel.unbind('broad-cast-supplier', handleNotification);
            pusher.unsubscribe(`private-supplier.${user.id}`);
          };
      }
  }


  return (
    <>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
        transition={Bounce}
      />
      <ToastContainer />
    </>
  );
};

export default PrivateChannelComponent;
