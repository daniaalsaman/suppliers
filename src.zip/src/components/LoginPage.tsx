"use client";
import { Input, Spinner } from "@nextui-org/react";
import React, { useState } from "react";
import * as Yup from "yup";
import { useFormik } from "formik";
import ForGotPwsModal from "./layout/ForGotPwsModal";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { classNames } from "primereact/utils";
import { authLogin, authRegister } from "../Api/Services";
import { useTranslation } from "react-i18next";
import { EyeSlashFilledIcon } from "./icons/EyeSlashFilledIcon";
import { EyeFilledIcon } from "./icons/EyeFilledIcon";
import OtpVerifyCodeModel from "./layout/OtpVerifyCodeModel";

function LoginPage() {
  const [isSignUpActive, setIsSignUpActive] = useState(false);
  const [isVisible, setIsVisible] = React.useState(false);
  const [isVisibleSignUp, setIsVisibleSignUp] = React.useState(false);
  const toggleVisibility = () => setIsVisible(!isVisible);
  const toggleSignUp = () => setIsVisibleSignUp(!isVisibleSignUp);
  const [isOtpModalOpen, setIsOtpModalOpen] = useState<boolean>(false);
  const { t } = useTranslation();

  const register = useFormik({
    initialValues: {
      first_name: "",
      last_name: "",
      email: "",
      password: "",
      password_confirmation: "",
    },
    validationSchema: Yup.object({
      // first_name: Yup.string().required('Name is required'),
      // last_name: Yup.string().required('Name is required'),
      email: Yup.string()
        .email("Invalid email format")
        .required("Email is required"),
      password: Yup.string()
        .required("password is required")
        .matches(
          /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,}$/,
          "Password must be at least 8 characters long and contain one uppercase letter and one or more symbols"
        ),
      password_confirmation: Yup.string()
        .min(6, "Password must be at least 6 characters")
        .required("Password is required")
        .oneOf([Yup.ref("password")], "Passwords must match"),
    }),
    onSubmit: async (values, { setSubmitting }) => {
      try {
        await authRegister(values).then((res: any) => {
          if(res.data) {
            togglePanel();
            setIsOtpModalOpen(true);
          }
        });
      } finally {
        setSubmitting(false);
      }
    },
  });

  const login = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email("Invalid email format")
        .required("Email is required"),
      password: Yup.string()
        .min(8, "Password must be at least 8 characters")
        .required("Password is required"),
    }),
    onSubmit: async (values, { setSubmitting }) => {
      try {
        const response = await authLogin(values);
        const accessToken = response.data.access_token;
        if (typeof window !== "undefined" && window.localStorage) {
          localStorage.setItem("token", accessToken);
          localStorage.setItem("User", JSON.stringify(response));
        }
      } catch (error) {
      } finally {
        setSubmitting(false);
      }
    },
  });

  const togglePanel = () => {
    setIsSignUpActive(!isSignUpActive);
  };

  return (
    <div className="loginPage">
      <div className="App">
        <div id="container" className={`container ${isSignUpActive ? "right-panel-active" : ""}`}>
          <div className="form-container sign-up-container">
            <form
              onSubmit={register.handleSubmit}
              className="!grid grid-cols-2 !gap-5 h-auto content-center"
            >
            <img src="https://doshtu-app.com/public/assets/project-logo.svg" className="h-100 w-100" alt="main_logo"/>
              <h1 className="col-span-2">{t("createaccount")}</h1>

              <div className="flex flex-col text-start">
                <InputText
                  type="text"
                  placeholder={t("firstname")}
                  defaultValue={register.values.first_name}
                  name="first_name"
                  value={register.values.first_name}
                  onChange={register.handleChange}
                  className={classNames({
                    "p-error":
                      register.touched.first_name && register.errors.first_name,
                  })}
                />
                <small className="p-error">{register.errors.first_name}</small>
              </div>

              <div className="flex flex-col text-start">
                <InputText
                  type="text"
                  placeholder={t("lastname")}
                  name="last_name"
                  value={register.values.last_name}
                  onChange={register.handleChange}
                  className={classNames({
                    "p-error":
                      register.touched.last_name && register.errors.last_name,
                  })}
                />
                <small className="p-error">{register.errors.last_name}</small>
              </div>

              <div className="flex flex-col text-start col-span-2">
                <InputText
                  type="email"
                  name="email"
                  placeholder={t("email")}
                  defaultValue={register.values.email}
                  onChange={register.handleChange}
                  className={classNames({
                    "p-error": register.touched.email && register.errors.email,
                  })}
                />
                <small className="p-error">{register.errors.email}</small>
              </div>

              <div className="flex flex-col text-start">
                <Input
                  radius="sm"
                  size="sm"
                  name="password"
                  variant="bordered"
                  classNames={{
                    base: "col-span-1",
                    errorMessage: "text-start",
                  }}
                  placeholder={t("password")}
                  defaultValue={register.values.password}
                  isInvalid={register.touched.password}
                  errorMessage={register.errors.password}
                  endContent={
                    <div
                      className="focus:outline-none cursor-pointer"
                      onClick={toggleVisibility}
                    >
                      {isVisible ? (
                        <EyeSlashFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                      ) : (
                        <EyeFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                      )}
                    </div>
                  }
                  type={isVisible ? "text" : "password"}
                  onChange={register.handleChange}
                />
              </div>

              <div className="flex flex-col text-start">
                <Input
                  radius="sm"
                  size="sm"
                  name="password_confirmation"
                  variant="bordered"
                  classNames={{
                    base: "col-span-1",
                    errorMessage: "text-start",
                  }}
                  placeholder={t("passwordConfirm")}
                  defaultValue={register.values.password_confirmation}
                  isInvalid={register.touched.password_confirmation}
                  errorMessage={register.errors.password_confirmation}
                  endContent={
                    <div
                      className="focus:outline-none cursor-pointer"
                      onClick={toggleSignUp}
                    >
                      {isVisibleSignUp ? (
                        <EyeSlashFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                      ) : (
                        <EyeFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                      )}
                    </div>
                  }
                  type={isVisibleSignUp ? "text" : "password"}
                  onChange={register.handleChange}
                />
              </div>

              <div className="col-span-2">
                <Button type="submit" disabled={register.isSubmitting}>
                  {register.isSubmitting ? (
                    <Spinner color="white" size="sm" />
                  ) : (
                    t("signUp")
                  )}
                </Button>
              </div>
            </form>
          </div>

          <OtpVerifyCodeModel
            isOpen={isOtpModalOpen}
            passEmail={register.values.email}
            onOpenChange={() => setIsOtpModalOpen(!isOtpModalOpen)}
            children={undefined}
          />

          <div className="form-container sign-in-container">
            <form onSubmit={login.handleSubmit}>
            <img src="https://doshtu-app.com/public/assets/project-logo.svg" className="h-100 w-100" alt="main_logo"/>
              <h1>{t("signin")}</h1>
              <div className="flex flex-col text-start w-2/3 p-float-label">
                <InputText
                  type="email"
                  name="email"
                  placeholder={t("email")}
                  defaultValue={login.values.email}
                  onChange={login.handleChange}
                  className={classNames({
                    "p-error": login.touched.email && login.errors.email,
                  })}
                />
                <label className="p-error">Email {login.errors.email}</label>
              </div>

              <div className="flex flex-col text-start w-2/3 p-float-label">
                <Input
                  radius="sm"
                  size="sm"
                  name="password"
                  variant="bordered"
                  classNames={{
                    base: "col-span-1",
                    errorMessage: "text-start",
                  }}
                  placeholder={t("password")}
                  defaultValue={login.values.password}
                  isInvalid={login.touched.password}
                  errorMessage={login.errors.password}
                  endContent={
                    <div
                      className="focus:outline-none cursor-pointer"
                      onClick={toggleSignUp}
                    >
                      {isVisibleSignUp ? (
                        <EyeSlashFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                      ) : (
                        <EyeFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                      )}
                    </div>
                  }
                  type={isVisibleSignUp ? "text" : "password"}
                  onChange={login.handleChange}
                />
              </div>

              <div className="">
                  <ForGotPwsModal />

                  <button
                    className="!bg-white !opacity-75 !inline !font-normal !text-[10px] !text-gray-900 !p-2 !m-2"
                    onClick={() => setIsOtpModalOpen(!isOtpModalOpen)}
                  >
                    {t("OpenOTPModal")}
                  </button>
              </div>

              <Button type="submit" disabled={login.isSubmitting}>
                {login.isSubmitting ? (
                  <Spinner color="white" size="sm" />
                ) : (
                  t("signin")
                )}
              </Button>
            </form>
          </div>

          <div className="overlay-container">
            <div className="overlay">
              <div className="overlay-panel overlay-left">
                <h1>{t("welcomemsg")}</h1>
                <p>{t("loginmsg")}</p>
                <Button className="ghost" id="signIn" onClick={togglePanel}>
                  {t("signin")}
                </Button>
              </div>

              <div className="overlay-panel overlay-right">
                <h1>{t("HelloSignIn")}</h1>
                <p>{t("Entermsg")}</p>
                <Button className="ghost" id="signUp" onClick={togglePanel}>
                  {t("signUp")}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
