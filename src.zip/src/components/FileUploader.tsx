"use client"
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Image } from 'primereact/image';

type FileUploadProps = {
    onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    name: string;
    containerClass?: string
    dividClass?: string
    labelClass?: string
    inputClass?: string
    value?: string
    multiple?: boolean
    path?: string
    selectImage? : any[];
  };

const FileUpload: React.FC<FileUploadProps> = ({
    onChange,
    name,
    containerClass = '',
    dividClass = '',
    labelClass = '',
    inputClass = '',
    multiple = false,
    path = '',
    selectImage = []
  }: FileUploadProps) => {

    const {t, i18n} = useTranslation()
     return (
    <div className={`file-upload-container overflow-hidden ${containerClass}`}>
      <div id="start" className={`${dividClass}`}>
        <i className="fa fa-download" aria-hidden="true"></i>
        <div>{t('selectfilemsg')}</div>
      </div>

      <label className={`file-upload-label ${labelClass}`}>{t('choosefile')}</label>
      <input
        className={`file-upload-input ${inputClass}`}
        type="file"
        name={name}
        multiple={multiple}
        onChange={onChange}
      />
      <div className="">
</div>
{ selectImage.length >0 ?  
  selectImage?.map((image:any, index:any) => (
    <Image key={index} src={image} alt={`Selected ${index}`} preview  />
  ))
: 
<Image
src={path} preview
/>
}
     
    </div>
  );
  };

  export default FileUpload;
