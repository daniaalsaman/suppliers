import React from 'react'

type Props = {}

const UploadIcon = (props: Props) => {
    return (
        <svg width="14" height="15" viewBox="0 0 14 15" xmlns="http://www.w3.org/2000/svg">
            <path d="M1.00024 11.1666V12.6666C1.00024 13.0644 1.15828 13.4459 1.43958 13.7272C1.72088 14.0085 2.1024 14.1665 2.50022 14.1665H11.5001C11.8979 14.1665 12.2794 14.0085 12.5607 13.7272C12.842 13.4459 13.0001 13.0644 13.0001 12.6666V11.1666" stroke="#5D596C" stroke-linecap="round" strokeLinejoin="round" />
            <path d="M3.25024 5.1667L7.00019 1.41675L10.7501 5.1667" stroke="#5D596C" stroke-linecap="round" strokeLinejoin="round" />
            <path d="M7 1.41675V10.4166" stroke="#5D596C" stroke-linecap="round" strokeLinejoin="round" />
        </svg>
    )
}

export default UploadIcon