import React, { useState } from "react";
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { useTranslation } from "react-i18next";

interface Municipality {
    name: string;
    code: string;
}
type Props = {
    municipalities: Municipality[],
    className: string,
    formik: any,
    selectedneighborhoods:any;
}

export default function MunicipalitySelect({ municipalities, className, formik , selectedneighborhoods }: Props) {
    const [selectedMunicipality, setSelectedMunicipality] = useState<Municipality | null>(null);
    const {t, i18n} = useTranslation()

    return (
        <div className={`card flex justify-content-center ${className}`} >
            <Dropdown value={selectedMunicipality}
                aria-placeholder="municipalities"
                onChange={(e: DropdownChangeEvent) => {
                    setSelectedMunicipality(e.target.value);
                    selectedneighborhoods(e.target.value.id)  
                    formik.setFieldValue('municipalities', e.value.code);
                }}
                options={municipalities}
                optionLabel="name"
                placeholder={t('selectMunicipality')}
                filter className="w-full md:w-14rem"
                aria-disabled={municipalities?.length <= 0}
            />
        </div>
    )
}
