import React, { useState } from "react";
import { Dropdown, DropdownChangeEvent } from "primereact/dropdown";
import { useTranslation } from "react-i18next";

type Props = {
  countries: any[];
  placeholder: string;
  className: string;
  formik: any;
  selectCityByCountry: any;
};

export default function CountrySelect({
  countries,
  placeholder,
  className,
  formik,
  selectCityByCountry,
}: Props) {
  const [selectedCountry, setSelectedCountry] = useState<any>(null);
  const {t, i18n} = useTranslation()

  const selectedCountryTemplate = (option: any) => {
    if (option) {
      return (
        <div className="flex align-items-center">
          <img
            alt={option.name}
            src="https://primefaces.org/cdn/primereact/images/flag/flag_placeholder.png"
            className={`mr-2 flag flag-${option.code.toLowerCase()}`}
            style={{ width: "18px" }}
          />
          <div>{option.name}</div>
        </div>
      );
    }

    return <span>{placeholder}</span>;
  };

  const countryOptionTemplate = (option: any) => {
    return (
      <div className="flex align-items-center">
        <img
          alt={option.name}
          src="https://primefaces.org/cdn/primereact/images/flag/flag_placeholder.png"
          className={`mr-2 flag flag-${option.code.toLowerCase()}`}
          style={{ width: "18px" }}
        />
        <div>{option.name}</div>
      </div>
    );
  };

  return (
    <div className={`card flex justify-content-center ${className}`}>
      <Dropdown
        value={selectedCountry}
        onChange={(selectedOption: any) => {
          setSelectedCountry(selectedOption.target.value);
          selectCityByCountry(selectedOption.target.value);
        }}
        options={
          Array.isArray(countries)
            ? countries.map((country) => ({
                label: country.name,
                value: country.id,
              }))
            : []
        }
        optionLabel="label"
        optionValue="value"
        placeholder={t('selectCountry')}
        filter
        className="w-full md:w-14rem"
      />
    </div>
  );
}
