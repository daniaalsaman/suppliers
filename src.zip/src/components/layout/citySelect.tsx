import React, { useState } from "react";
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { useTranslation } from "react-i18next";

interface City {
    name: string;
    code: string;
}
type Props = {
    cities: City[],
    placeholder: string,
    className: string,
    formik: any,
    selectMunicipalityByCity: any,
}

export default function CitySelect({ cities, placeholder, className, formik,selectMunicipalityByCity }: Props) {
    const [selectedCity, setSelectedCity] = useState<City | null>(null);
    const {t, i18n} = useTranslation()

    return (
        <div className={`card flex justify-content-center ${className}`} >
            <Dropdown value={selectedCity} onChange={(e: DropdownChangeEvent) => {
                setSelectedCity(e.value);
                formik.setFieldValue('cities', e.target.value.id);
                selectMunicipalityByCity(e.target.value.id)                
            }}  options={cities} optionLabel="name" 
                placeholder={t('selectCity')}
                filter className="w-full md:w-14rem" />
        </div>
    )
}
