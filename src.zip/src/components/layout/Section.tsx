import React from 'react'

type Props = {
    title?: string,
    className?: string,
    titleClassName?: string,
    children?: React.ReactNode
}

const Section = ({ title, children, className ,titleClassName }: Props) => {
    return (
        <div className={`rounded-md h-fit bg-white p-5 gap-3 ${ className }`}>
            {title && <h1 className={`font-semibold w-full ${titleClassName}`}>{title}</h1>}
            {children}
        </div>
    )
}

export default Section