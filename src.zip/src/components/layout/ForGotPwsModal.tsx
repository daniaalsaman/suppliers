import React from "react";
import { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, Button, useDisclosure } from "@nextui-org/react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { forgotPassword } from "../../Api/Services";
import { useTranslation } from "react-i18next";
import { InputText } from "primereact/inputtext";

export default function ForGotPwsModal() {
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const { t, i18n } = useTranslation();

  let initialValues = {
    email: "",
    code: "",
  };

  const formik = useFormik({
    initialValues: initialValues,
    validationSchema: Yup.object({
      email: Yup.string()
        .email("Invalid email format")
        .required("Email is required"),
    }),
    onSubmit: async (values, { setSubmitting }) => {
      await forgotPassword(values);
      onOpenChange();
      setSubmitting(false);
    },
  });

  const [isVisible, setIsVisible] = React.useState(false);
  const toggleVisibility = () => setIsVisible(!isVisible);

  return (
    <>
      <a href="#" onClick={onOpen}>
        {t("forgetpass")}
      </a>
      <Modal isOpen={isOpen} onOpenChange={onOpenChange} className="z-10">
        <ModalContent>
          {(onClose) => (
            <>
              <ModalHeader className="flex flex-col gap-1">
                {t("forgetpass")}
              </ModalHeader>
              <ModalBody>
                <form
                  onSubmit={formik.handleSubmit}
                  className="flex flex-col gap-5"
                >
                  <InputText
                    name="email"
                    placeholder={t("email")}
                    value={formik.values.email}
                    onChange={formik.handleChange}
                  />

                  <InputText
                    name="code"
                    placeholder={t("code")}
                    value={formik.values.code}
                    onChange={formik.handleChange}
                  />
                </form>
              </ModalBody>
              <ModalFooter>
                <Button color="danger" variant="light" onPress={onClose}>
                  {t("cancel")}
                </Button>
                <Button color="primary" onPress={formik.submitForm}>
                  {t("send")}
                </Button>
              </ModalFooter>
            </>
          )}
        </ModalContent>
      </Modal>
    </>
  );
}
