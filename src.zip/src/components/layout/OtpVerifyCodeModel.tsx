import React from "react";
import { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, Button, ModalProps } from "@nextui-org/react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { otpVerfiy } from "../../Api/Services";
import { useTranslation } from "react-i18next";
import { InputText } from "primereact/inputtext";
import { classNames } from "primereact/utils";

interface OtpVerifyCodeModelProps extends ModalProps {
  isOpen: boolean;
  passEmail: string;
  onOpenChange: () => void;
}

export default function OtpVerifyCodeModel({ isOpen, passEmail, onOpenChange }: OtpVerifyCodeModelProps) {
  const { t } = useTranslation();

  const formik = useFormik({
    initialValues: {
      email: passEmail ?? "",
      code: "",
    },
    enableReinitialize: true,
    validationSchema: Yup.object({
      email: Yup.string().email("Invalid email format").required("Email is required"),
      code: Yup.string().required("Code is required").length(6, "Code must be 6 digits!"),
    }),
    onSubmit: async (values, { setSubmitting }) => {
      try {
        await otpVerfiy(values).then((res: any) => {
          console.log(res, 'any');
        });

        onOpenChange();
      } catch (error) {
        console.error("Error verifying OTP:", error);
      } finally {
        setSubmitting(false);
      }
    },
  });

  return (
    <Modal isOpen={isOpen} onOpenChange={onOpenChange} className="z-10">
      <ModalContent>
        {(onClose) => (
          <>
            <ModalHeader className="flex flex-col gap-1">{t("OtpVerfiy")}</ModalHeader>

            <ModalBody>
              <form onSubmit={formik.handleSubmit} className="flex flex-col gap-5">


              <div className="flex flex-col text-start">
                  <InputText
                    name="email"
                    placeholder={t("email")}
                    value={passEmail ?? formik.values.email}
                    onChange={formik.handleChange}
                    className={classNames({
                        "p-error": formik.touched.email && formik.errors.email,
                    })}
                  />
                  <label className="p-error">Email {formik.errors.email}</label>
              </div>

              <div className="flex flex-col text-start">
                <InputText
                  name="code"
                  placeholder={t("code")}
                  value={formik.values.code}
                  onChange={formik.handleChange}
                  className={classNames({
                      "p-error": formik.touched.code && formik.errors.code,
                  })}
                />
                <label className="p-error">Code {formik.errors.code}</label>
              </div>

              </form>
            </ModalBody>

            <ModalFooter>
              <Button color="danger" variant="light" onPress={onClose}>{t("cancel")}</Button>
              <Button color="primary" onPress={formik.submitForm}>{t("send")}</Button>
            </ModalFooter>
          </>
        )}
      </ModalContent>
    </Modal>
  );
}
