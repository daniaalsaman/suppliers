"use client";
import { useRouter } from "next/navigation";
import { Menubar } from "primereact/menubar";
import { useEffect, useRef, useState } from "react";
import { MarkNotifications, Notifications, authLogout } from "../../Api/Services";
import ReactFlagsSelect from "react-flags-select";
import { useTranslation } from "react-i18next";
import { Avatar } from "primereact/avatar";
import { Menu } from "primereact/menu";
import { Badge } from "@nextui-org/react";
import { READ_BANK_ACCOUNTS, READ_NOTIFICATIONS } from "@/permissions/permissions";

function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean | null | undefined>();
  const [notifications, setNotifications] = useState<any>();
  const [Readnotifications, setReadNotifications] = useState<any>();
  const [displayedNotifications, setDisplayedNotifications] = useState<any>();
  const menuLeft = useRef<any>(null);
  const menuNotifications = useRef<any>(null);
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const user = typeof window !== 'undefined' && window.localStorage ? JSON.parse(localStorage.getItem("User") as any) : "";
  const fullName = user?.data?.fullName;
  const logo = user?.data?.supplier?.logo
  const isRTL = i18n.language === "ar";

  const handleLogout = () => {
    setIsLoggedIn(false);
    if(typeof window !== 'undefined' && window.localStorage) {
      localStorage.removeItem("token");
      localStorage.removeItem("User");
    }
    authLogout()
  };

  const [selected, setSelected] = useState(
    typeof window !== 'undefined' && window.localStorage ?
    localStorage.getItem("i18nextLng") === "ar"
      ? "SA"
      : localStorage.getItem("i18nextLng")?.toUpperCase() ?? "US" : ""
  );
  useEffect(() => {
    Notifications().then((res) => {
      setNotifications(res.data);
      setDisplayedNotifications(res.data?.slice(0, 5));
    });
  }, []);
  console.log(Readnotifications)

  const handleMenuShow = () => {
    setTimeout(() => {
      const menuElement = menuNotifications.current.getElement();
      if (menuElement) {
        menuElement.style.backgroundColor = '';
        menuElement.style.boxShadow       = 'unset';
        menuElement.style.transformOrigin = 'unset';
        menuElement.style.top             = '75px';
        menuElement.style.left            = 'unset';
        menuElement.style.right           = '300px';
        menuElement.style.width           = '300px';
        menuElement.style.zIndex          = '0';
      }
    }, 0);
  };
const handleNotifyChange = (id:number) =>{
  let data ={
    notification_id:id
}
MarkNotifications(data).then((res)=>setReadNotifications(res?.data))
}
  const handleMenuHide = () => {
    const menuElement = menuNotifications.current.getElement();
    if (menuElement) {
      menuElement.style.backgroundColor = '';
      menuElement.style.boxShadow = '';
      menuElement.style.top = '';
      menuElement.style.left = '';
      menuElement.style.right = '';
      menuElement.style.width = '';
      menuElement.style.zIndex = '';
    }
  };
  const navbarItems = [
    {
      label: fullName,
      items: [
        {
          label: t("myprofile"),
          icon: "pi pi-user",
          command: () => router.push("/profile"),
        },
        {
          label: t("banksaccounts"),
          icon: "pi pi-building",
          command: () => router.push("/banks"),
          condition : READ_BANK_ACCOUNTS()
        },
        {
          label: t("logout"),
          icon: "pi pi-sign-out",
          command: () => handleLogout(),
        },
      ].filter((e: any) => (e.condition === undefined ? true : e.condition))
    },
  ];

  const notificationItems: any[] = [
    {
      className: 'notification-items',
      label: (
        <div className="notification-menu">
          {displayedNotifications && displayedNotifications.length > 0 ? (
            displayedNotifications.map((notify: any, index: number) => (
              <div key={notify.id} onClick={()=>handleNotifyChange(notify.id)} style={Readnotifications?.id === notify?.id ? {backgroundColor:'white'} : {backgroundColor:''}}
              className={`relative overflow-hidden py-2 px-3 hover:border-slate-400 hover:bg-slate-200 ${index !== displayedNotifications.length - 1 ? '' : ''} border-b border-neutral-200`}>
                <div className="mt-2 mx-4 flex justify-center items-center">
                  <div className="content mr-[20px] mb-[18px] overflow-hidden">
                    <h2 className="font-bold text-lg text-gray-900">{notify?.title}:</h2>
                    <span className="text-sm text-gray-700">{notify.description}</span>
                  </div>
                  <div className="flex justify-center items-center p-2 mb-4 text-white bg-[#ea5455] border-1 border-white-200 w-max h-max rounded-full">
                    <i className="pi pi-bold pi-bell w-full h-full"></i>
                  </div>
                  <span className="absolute bottom-2 right-2 text-xs text-gray-500">{notify.created_at}</span>
                </div>
              </div>
            ))
          ) : (
            <span className="" style={{ minHeight: '200px', display: 'flex', justifyContent: 'center', alignItems: 'center'}}>{t("noNotificationsToDisplay")}</span>
          )}

          <div className="flex justify-between items-center px-4 py-5 bg-[#ea5455] text-white border-b border-neutral-200 p-4">
            <button className="text-sm text-white-700 hover:text-white-900 flex justify-center items-center" onClick={()=> router.push("/notifications")}>
              <span className="mx-2">{t("showAllNotifications")}</span>
               <i className="pi pi-arrow-circle-right fade-infinite text-md"></i>
            </button>
          </div>
        </div>
      )
    }
  ];

  const barItems = (
    <div className="flex justify-center items-center p-1">
      <div className="flags-select flex justify-center items-center mx-2">
      <ReactFlagsSelect
        selected={selected}
        onSelect={(code) => {
          setSelected(code);
          if (code === "SA") {
            i18n.changeLanguage("ar");
            window.location.reload();
          } else if (code === "US") {
            i18n.changeLanguage("en");
            window.location.reload();
          } else {
            i18n.changeLanguage(code.toLowerCase());
            window.location.reload();
          }
        }}
        countries={["US", "SA", "TR"]}
      />

      </div>

      <div className="notifications flex justify-center items-center mx-2">
        {READ_NOTIFICATIONS() ?
          <Badge content={notifications?.length  } shape="circle" color="primary" className="text-[10px]">
            <i className="pi pi-bold pi-bell mt-1 text-lg" style={{ cursor: "pointer" }} onClick={(event) => menuNotifications.current.toggle(event)}></i>
          </Badge>
        : <></>}
      </div>

      <div className="avatar flex justify-center items-center mx-2">
        <Avatar image={logo} className="mx-2 mt-1" onClick={(event) => menuLeft.current.toggle(event)} shape="circle" style={{ cursor: "pointer" }} />
        <h3 className="mt-2 mr-2 font-bold"> {fullName}</h3>
      </div>
    </div>
  );

  return (
    <div className="card custom-background custom-box-shadow">
      <Menu model={notificationItems} popup ref={menuNotifications} className="border border-neutral-200 p-0"
        style={{minWidth: '300px'}}
        onShow={handleMenuShow}
        onHide={handleMenuHide}
      />
      <Menu model={navbarItems} popup ref={menuLeft} className="popup-left" />
      <Menubar end={barItems} className="Navbar" dir={isRTL ? "rtl" : "ltr"} />
    </div>
  );
}

export default Header;
