"use client";

import { Dropdown } from "primereact/dropdown";
import FilterIcon from "../icons/FilterIcon";
import Link from "next/link";
import { Button } from "primereact/button";
import { InputText } from "primereact/inputtext";
import { Sidebar } from "primereact/sidebar";
import { useEffect, useState , useRef } from "react";
import { Dialog } from "primereact/dialog";
import FileUpload from "../FileUploader";
import { ImportProducts, getCategories, getProductList } from "@/Api/Services";
import { useTranslation } from "react-i18next";
import { CREATE_PRODUCTS } from "@/permissions/permissions";
import { InputNumber } from "primereact/inputnumber";
import { Message } from "primereact/message";

type Props = {
  isshown: boolean;
  search : ()=>any
  onData: any,
  onFiltermaxPriceData: any,
  onFilterminPriceData: any,
  onFilterCategoryData: any,
  FilterSearch : ()=> any,
};

function Filter(props: Props) {
    const [visible, setVisible] = useState(false);
    const [show, setShow] = useState(false);
    const [selectedItem, setSelectedItem] = useState(null);
    const [selectedfile, setSelectedfile] = useState();
    const [file, setFile] = useState<any>();
    const [url , setUrl] = useState()
    const {t} = useTranslation()
    const items2 = Array.from({ length: 100000 }).map((_, i) => ({ label: `Item #${i}`, value: i }));
    const [minPricevalue, setMinPriceValue] = useState<any>(0);
    const [maxPricevalue, setMaxPriceValue] = useState<any>(0);
    const [categories, setCategories] = useState<any[]>();
    const [message , setMessage] = useState<any>();
    const [inputValue, setInputValue] = useState<any>();

    const Options =[{
        label: "CSV",
        value :"CSV"
    },{
        label: "XML",
        value:"XML"
    }]

    function handleChange(event: any) {
      setFile(event.target.files[0]);
    }
    useEffect(() => {
      getCategories().then((e: any) => {
        setCategories(e.data.categories);
      });
    }, []);
    const Import = () =>{
      let data ={
          type: selectedfile,
          file:file,
          url:url
      }
      const formData = new FormData();
      formData.append("type", selectedfile as any);
      formData.append("file", file);
      formData.append("url", url as any);
      ImportProducts(formData).then((res)=>setMessage(res.data))
      setShow(false)
    }
    const handleClick = () => {
      props.onData(inputValue); 
      props.search()
    };
    const handleFilterClick = () => {
      props.onFilterminPriceData(minPricevalue); 
      props.onFiltermaxPriceData(maxPricevalue); 
      props.onFilterCategoryData(selectedItem); 
      props.FilterSearch()
    };
    const handleSearchChange = (event:any) => {
      setInputValue(event.target.value);
    };
    
    return (
      <div className='bg-white w-full h-fit p-3 rounded-md flex gap-3 items-center justify-between flex-nowrap overflow-auto' {...props}>
          <div className="flex gap-3 md:w-1/2">
              <InputText placeholder={t('search')} size='small' type="text" className="w-2/3 min-w-max whitespace-nowrap" onChange={(e)=>handleSearchChange(e)} />
              <Button  severity="danger" icon="pi pi-search" size="small"  onClick={handleClick}/>

              <Button
                size="small"
                title="filter"
                className="font-semibold flex gap-3 border-0 text-white"
                onClick={() => setVisible(true)}
                severity="danger"
              >
                <span className="md:block hidden text-white">{t('filters')}</span>
                <FilterIcon />
              </Button>
              {message!== undefined ? <Message content = {message} /> : <></>}
              <Sidebar visible={visible} position="right" onHide={() => setVisible(false)}>
                  <div className="flex flex-col gap-3" >
                  <label> {t('minprice')}</label>
                  <InputNumber placeholder={'Min Price'} inputId="locale-user" value={minPricevalue} onValueChange={(e) => setMinPriceValue(e.value)} />
                  <label> {t('maxprice')}</label>
                  <InputNumber placeholder={'Max Price'} inputId="locale-user" value={maxPricevalue} onValueChange={(e) => setMaxPriceValue(e.value)} />
                  <label> {t('categories')}</label>
                  <Dropdown value={selectedItem} onChange={(e) => setSelectedItem(e.value)} options={categories} virtualScrollerOptions={{ itemSize: 38 }}
                          optionLabel="title"
                          optionValue="id"  placeholder={t('categories')} className="w-full md:w-14rem" />
                  <Button label="Search" severity="danger" className="mt-4" onClick={handleFilterClick}/>

                  </div>
              </Sidebar>
          </div>

          <Dialog
            header={t('importproductfile')}
            visible={show}
            style={{ width: "40vw" }}
            onHide={() => setShow(false)}
            footer={
              <>
                <div>
                  <Button
                    label={t("import")}
                    severity="info"
                    size="small"
                    onClick={() => Import()}
                    className="mt-4"
                  ></Button>

                  <Button
                    label={ t("cancel")}
                    severity="danger"
                    outlined
                    size="small"
                    onClick={() => setShow(false)}
                    className="mt-4"
                  ></Button>

                </div>
              </>
            }
          >
            <div className="grid overflow-hidden gap-4">
              <div className="col ">

                <label className="mb-2" htmlFor="Wallet">{t('type')}</label>

                <div>
                  <Dropdown
                    optionLabel="label"
                    optionValue="value"
                    value={selectedfile}
                    options={Options}
                    onChange={(e) =>
                      setSelectedfile(e.target.value)
                    }
                    placeholder={
                    t('filemsg')
                    }
                    className="w-full"
                  />
                </div>
              </div>

              { selectedfile === 'XML' ?
              <div className="col ">
                  <label className="mb-2" htmlFor="Status">
                    {"URL "}
                  </label>
                  <div>
                  <InputText
                  placeholder="URL"
                  value={url}
                  onChange={(e:any)=> setUrl(e.target.value)}
                  className="w-full"
                  /></div>
              </div>
            : selectedfile === 'CSV' ?
            <div>
              <FileUpload onChange={handleChange} name="" />
            </div> : <></>
            }
            </div>
          </Dialog>

          {CREATE_PRODUCTS()? <div className="flex gap-3 items-center">
              <Button className="mr-2 flex gap-3" severity="danger" size="small" label={t('import')}
                icon='pi pi-plus' onClick={()=>setShow(true)} aria-controls="popup_menu_right" aria-haspopup >
              </Button>

              <Link href={`/products/add`} className=" flex gap-3 justify-between px-4 font-semibold capitalize" >
                  <Button label={t('addproduct')} severity="danger" size="small" icon='pi pi-plus'> </Button>
              </Link>
          </div>:<></>}
      </div>
    )
}

export default Filter
