"use client"
import SideBarBtn from "@/components/icons/sideBarBtn";
import { Accordion, AccordionItem } from "@nextui-org/react";
import { useState } from "react";
import SubItemIcon from "../icons/SubItemIcon";
import Link from "next/link";
import { useTranslation } from "react-i18next";
import { READ_CATEGORIES, READ_COMPLAINTS, READ_EMPLOYEES, READ_ORDERS, READ_PRODUCTS } from "@/permissions/permissions";

type Props = {}

export default function Sidebar({ }: Props) {
    const [collapsed, setCollapsed] = useState(false);
    const toggle = () => setCollapsed(!collapsed);
    const {t, i18n} = useTranslation()
    const isRTL = i18n.language === "ar";

    const navData = [
        {
            "label": t("Analytics"),
            "href": "/analytics",
            "icon":"pi pi-chart-bar",
            "condition":true
        },
        {
            "label": t("product"),
            "href": "/products",
            "icon":"pi pi-inbox ",
            "children": [
                {
                    "label":  t("product"),
                    "href": "/products",
                    "icon":"pi pi-chart-bar",
                    "condition":READ_PRODUCTS()
                },
                {
                    "label": t("categories"),
                    "href": "/categories",
                    "icon":"pi pi-chart-bar",
                    "condition":READ_CATEGORIES()
                },
                {
                    "label": t("attributes"),
                    "href": "/attributes",
                    "icon":"pi pi-chart-bar",
                    "condition":READ_CATEGORIES()
                }
            ]
        },
        {
            "label": t("orders"),
            "href": "/orders",
            "icon":"pi pi-truck",
            "condition":READ_ORDERS()
        },
        {
            "label": t("employee"),
            "href": "/employee",
            "icon":"pi pi-users",
            "condition":READ_EMPLOYEES()

        },
        {
            "label": t("support"),
            "href": "/complaints",
            "icon":"pi pi-file",
            "condition":READ_COMPLAINTS()
        },
    ]

    return (
        <>
            <div dir={isRTL ? "rtl" : "ltr"} className={`py-2.5 md:relative md:translate-x-0 -translate-x-full start-0 top-0 px-3 bg-white transition-all custom-box-shadow ${collapsed ? 'w-16' : 'w-64'}`}>
                <div className="nav-item flex justify-between items-center" onClick={toggle}>
                    <img
                        width={138}
                        height={57}
                        className="max-h-16"
                        alt="Picture of the author"
                        src={collapsed ? '/assets/images/logo.svg' : '/assets/images/logoWithText.png'}
                    />
                    {!collapsed &&
                        <div className="md:block hidden">
                            <SideBarBtn />
                        </div>
                    }
                </div>
                <nav className="mt-12 flex flex-wrap gap-4">
                    {navData.map((nav, i) => {
                        if (nav.children && !collapsed) {
                            return (
                                <Accordion key={i} isCompact className="p-0 nav-item transition-all bg-white rounded" itemClasses={{
                                    base: "w-full",
                                    title: " hover:text-white",
                                    heading: "p-0 w-full",
                                    trigger: "p-2 bg-white hover:bg-primary transition-all hover:text-white rounded-md flex"
                                }} >


                                   <AccordionItem startContent={<i className={nav.icon} />} key="1" aria-label={nav.label} title={nav.label}>
                                        {nav.children
                                         .filter(subNav => subNav.condition === true ? true : false)
                                         .map((subNav, i) => (
                                            <Link href={subNav.href} key={i} className="nav-sub-item cursor-pointer nav-item p-2 transition-all bg-white hover:text-white rounded-md flex justify-start gap-2 items-center w-full">
                                                <SubItemIcon />
                                                <span className="capitalize whitespace-nowrap">
                                                    {subNav.label}
                                                </span>
                                            </Link>
                                        ))}
                                    </AccordionItem>
                                </Accordion>
                            )
                        } else {
                            if(nav.condition === true)
                           { return (
                                <>
                               <Link href={nav.href} key={i} className="nav-sub-item cursor-pointer nav-item p-2 transition-all bg-white hover:text-white rounded-md flex justify-start gap-2 items-center w-full" >
                                    <i className={nav.icon} />
                                    {!collapsed &&
                                        <span className=" capitalize whitespace-nowrap text-ellipsis">
                                            {nav.label}
                                        </span>
                                    }
                                </Link>
                                </>
                            )}
                            else {
                                return (<></>)
                            }
                        }
                    })}

                </nav>
            </div>
        </>
    )
}
