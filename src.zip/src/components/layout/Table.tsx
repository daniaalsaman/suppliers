"use client"
import React, { useEffect, useState } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { ConfirmDialog, confirmDialog } from "primereact/confirmdialog";
import Link from 'next/link';
import { Paginator } from 'primereact/paginator';
import { getProductList , deleteProduct } from '../../Api/Services';
import { useTranslation } from 'react-i18next';
import { Image } from 'primereact/image';
import { DELETE_PRODUCTS, UPDATE_PRODUCTS } from '@/permissions/permissions';
import PaginationTemplate from '../PaginationComponent';

type Props = {
  pagination : any
  products: any
  OnPageChange: any
}
function TableSection(props: Props) {
    const {t, i18n} = useTranslation()
    const imageBodyTemplate = (product: any) => {
        return <Image  src={product.images[0]} alt={product.image} width="80" height="40" preview />;
    };
    
    // Deleting usState 
    const accept = async (id:number) => {
            await  deleteProduct(id);
  }
    const confirm = (id: number) => {
        confirmDialog({
          message: t('deleteProductemsg'),
          header: t('deleteconfirm'),
          icon: "pi pi-info-circle",
          defaultFocus: "reject",
          acceptClassName: "p-button-danger py-2",
          rejectClassName: "p-button-outlined py-2",
          acceptLabel: t('delete'),
          rejectLabel: t('cancel'),
          accept: () => accept(id),
        });
      };

    const actionsTemplate = (product: any) => {
        return (
            <div className='flex gap-3'>
{             UPDATE_PRODUCTS()?   <Link
                    href={`/products/edit/${product.id}`}
                >
                    <i className='pi pi-file-edit'></i>
                </Link>:<></>}
{           DELETE_PRODUCTS()?    
                <i className='pi pi-trash pi pi-danger' onClick={() => confirm(product?.id)}/>:<></>
}
                  <Link
                    href={`/products/details/${product.id}`}
                >
                    <i className='pi pi-exclamation-circle'></i>
                </Link>
            </div>
        );
    };

    return (
        <>
              <ConfirmDialog />
            <DataTable
                value={props.products}
                loading={status == 'loading'}
                size='normal'
                 dataKey="id"
            >
                <Column header={t('image')} body={imageBodyTemplate}></Column>
                <Column sortable field='title' header={t('title')}></Column>
                <Column sortable field='category.title' header={t('category')}></Column>
                <Column sortable field='base_price' header={t('price')}></Column>
                <Column sortable field='publish_status' header={t('status')}></Column>
                <Column sortable field='quantity' header={t('quantity')}></Column>
                <Column header={t('actions')} body={actionsTemplate}></Column>
            </DataTable>
            {props.pagination&& (
                <PaginationTemplate
                  onPageChange={props.OnPageChange}
                  dataPagination={props.pagination!}
                />
              )}
        </>
    );
}

export default TableSection