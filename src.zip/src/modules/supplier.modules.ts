export class CountryDTO {
    id:number = 0;
    name:string = '';
    code:string = '';
}
export class CityDTO  {
    id:number = 0;
    name:string = '';
}

export class MunicipalityDTO  {
    id:number = 0;
    name:string ='';
}
export type Adress = {
    id:number;
    user_id:number;
    apartment: string | any;
    building: string | any;
    city: CityDTO | any;
    country:CountryDTO | any;
    floor:string | any;
    street:string |any;
    postal_code:string;
    more_details:string;
    latitude:number;
    longitude:number;
    municipality:MunicipalityDTO | any;
    neighborhood:any;
}
export class SubProductDTO {
    quantity: number = 0;
    sku: string = '';
    price: number = 0 ;
    active: boolean = false;
    height: number = 0;
    weight: number = 0;
    width: number = 0 ;
    length: number = 0 ;
    image?: any;
    sub_product_attribute?: any
}
export class ProductDTO {
    sku: number | any = 0;
    quantity: number  = 0;
    description: string = '' ;
    title: string = '';
    width: number | any = 0;
    height: number | any= 0;
    category: number | any= 0;
    base_price : number  = 0;
    publish_status: string = '';
    sub_product?: SubProductDTO[] | any;
    images?: any[] = [];
    weight: number = 0 ;
    length: number = 0;
}

export type Variants = {
  id: number ;
  name: string;
  values: SelectAttributesValue[];
}

export interface SelectAttributesName {
  id: string,
  attribute_name: string,
  values: SelectAttributesValue[],
}

export interface SelectAttributesValue {
  id: number,
  value: string,
  relat_name: string
}

export interface Combination {
  combinationText: string;
  namesAndValues: { nameId: any; valueId: any; }[];
}

export class AddComplaintDTO {
    type?: any ;
    description: string = "";
    attachments: File[] = [];
    id? : number 
  }
  export class BankDTO {
    account_number: string = "";
    bank_name: string = "";
    account_holder_name: string = "";
    account_type: string = "";
    branch_name: string = "";
    iban: string = "";
    ifsc_code: string = "";
    swift_code: string = "";
    currency?: any;
    balance: number = 0;
    is_primary: boolean = false;
  }

  export class EmployeeDTO {
    first_name:string = '';
    last_name:string = '';
    email : string = '';
    role? : any;
    password : string = '';
    status : string = '';
    country_id : number =0;
    city_id : number =0;
    municipality_id : number =0;
    neighborhood_id: number =0;
    street : string = '';
    building : string ='';
    floor : string ='';
    apartment : string ='';
    more_details: string ='';
    postal_code : string ='';

  }

  export type Supplier = {
    id: number;
    name: string | any;
    created_at: string;
    contact_number: string | any;
    commission:number;
    cover: string;
    xml_urls:string[];
    csv_files:string[];
    logo:string;
  };

  export interface IPagination {
    total: number;
    count: number;
    per_page: number;
    current_page: number;
    total_pages: number;
    has_more: boolean;
  }

  export class UserDTO {
    id: number = 0;
    first_name: string = "";
    fullName: string = "";
    last_name: string = "";
    wallet?: string | any;
    address?: Adress;
    supplier?: Supplier;
    email: string = "";
    municipalities?: number = 0;
    cities?: number = 0;
    countries?: number = 0;
    neighborhoods?:number =0;
    apartment: number = 0;
    floor: number = 0;
    building: number = 0;
    street: number = 0;
    supplier_logo?: any;
    supplier_cover?: any;
    retailer_name: string = "";
    supplier_contact_number: number = 0;
    data : any
  }
  export interface subCategory {
    appears_on_suggestions: number;
    title: string;
    commission: number;
    logo: string;
    parent_id: string;
    description: string;
    level: number;
    id: string;
  }
  export interface Category {
    appears_on_suggestions: number;
    title: string;
    commission: number;
    logo: string;
    parent_id: string;
    description: string;
    level: number;
    id: string;
    childrens?: subCategory[];
  }
  export interface Store {
    id: string;
    logo: string;
    name: string;
  }
  export interface selectStoreOption {
    name: string;
    value: string;
  }
  
  export interface subCategory {
    appears_on_suggestions: number;
    title: string;
    commission: number;
    logo: string;
    parent_id: string;
    description: string;
    level: number;
    id: string;
  }
  export interface Category {
    appears_on_suggestions: number;
    title: string;
    commission: number;
    logo: string;
    parent_id: string;
    description: string;
    level: number;
    id: string;
    childrens?: subCategory[];
  }
  export class FilterDTO {
    // categories?: Array<string> = [];
    categories?: Array<Category> = [];
    minPrice?: number = 0;
    maxPrice?: number = 0;
    available: number = 0;
    publishedOnStore: number = 0;
  }