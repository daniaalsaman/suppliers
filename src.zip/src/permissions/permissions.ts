const user = (typeof window !== 'undefined' && window.localStorage) ? JSON.parse(localStorage.getItem('User') as any) : null;

const permissions = user?.data?.authorizations?.permissions ?? [];

const hasPermission = (key: any) => permissions.some((permission: any) => permission[key]);
const createPermissionChecker = (key: any) => () => hasPermission(key) === true;

export const CREATE_BANK_ACCOUNT = createPermissionChecker('create_bank_accounts');
export const CREATE_AUTHORITIES = createPermissionChecker('create_authorities');
export const CREATE_COMPLAINTS = createPermissionChecker('create_complaints');
export const CREATE_CATEGORIES = createPermissionChecker('create_categories');
export const CREATE_EMPLOYEES = createPermissionChecker('create_employees');
export const CREATE_NOTIFICATIONS = createPermissionChecker('create_notifications');
export const CREATE_ORDERS = createPermissionChecker('create_orders');
export const CREATE_PRODUCTS = createPermissionChecker('create_products');

export const DELETE_BANK_ACCOUNTS = createPermissionChecker('delete_bank_accounts');
export const DELETE_CATEGORIES = createPermissionChecker('delete_categories');
export const DELETE_COMPLAINTS = createPermissionChecker('delete_complaints');
export const DELETE_EMPLOYEES = createPermissionChecker('delete_employees');
export const DELETE_NOTIFICATIONS = createPermissionChecker('delete_notifications');
export const DELETE_ORDERS = createPermissionChecker('delete_orders');
export const DELETE_PRODUCTS = createPermissionChecker('delete_products');

export const READ_BANK_ACCOUNTS = createPermissionChecker('read_bank_accounts');
export const READ_CATEGORIES = createPermissionChecker('read_categories');
export const READ_COMPLAINTS = createPermissionChecker('read_complaints');
export const READ_EMPLOYEES = createPermissionChecker('read_employees');
export const READ_NOTIFICATIONS = createPermissionChecker('read_notifications');
export const READ_ORDERS = createPermissionChecker('read_orders');
export const READ_PRODUCTS = createPermissionChecker('read_products');

export const UPDATE_BANK_ACCOUNTS = createPermissionChecker('update_bank_accounts');
export const UPDATE_CATEGORIES = createPermissionChecker('update_categories');
export const UPDATE_COMPLAINTS = createPermissionChecker('update_complaints');
export const UPDATE_EMPLOYEES = createPermissionChecker('update_employees');
export const UPDATE_NOTIFICATIONS = createPermissionChecker('update_notifications');
export const UPDATE_ORDERS = createPermissionChecker('update_orders');
export const UPDATE_PRODUCTS = createPermissionChecker('update_products');
