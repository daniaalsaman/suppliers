// app/providers.tsx
'use client'

import { AppStore, makeStore } from '@/lib/store'
import { NextUIProvider } from '@nextui-org/react'
import { getServerSideProps } from 'next/dist/build/templates/pages'
import { useEffect, useRef } from 'react'
import { Provider } from 'react-redux'

import { PrimeReactProvider } from 'primereact/api';
import PrivateChannelComponent from '@/pusher-notification/config'


export function Providers({ children }: { children: React.ReactNode }) {
    const storeRef = useRef<AppStore>()
    if (!storeRef.current) {
        // Create the store instance the first time this renders
        storeRef.current = makeStore()
    }
    PrivateChannelComponent()

  useEffect(()=>{
  },[])
    return (
        
        <Provider store={storeRef.current}>
            <NextUIProvider>
                <PrimeReactProvider >
                    {children}
                </PrimeReactProvider>
            </NextUIProvider>
        </Provider>
    )
}