"use client";
import { TabPanel, TabView } from "primereact/tabview";
import { useEffect, useRef, useState } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { useFormik } from "formik";
import { Button } from "primereact/button";
import { Tag } from "primereact/tag";
import { Dialog } from "primereact/dialog";
import { Dropdown } from "primereact/dropdown";
import { UpdateComplaint, createComplaint, getComplaint, getComplaintDefinitions} from "@/Api/Services";
import { AddComplaintDTO } from "@/modules/supplier.modules";
import FileUpload from "@/components/FileUploader";
import { useTranslation } from "react-i18next";
import { CREATE_COMPLAINTS, UPDATE_COMPLAINTS } from "@/permissions/permissions";

const Complaint = () => {
  const [Complaint, setComplaint] = useState<any>();
  const [showEdit, setShowEdit] = useState<boolean>(false);
  const [id, setId] = useState<any>();
  const [types, setTypes] = useState<any>();
  const [status, setStatus] = useState<any>();
  const [loading, setLoading] = useState(false);
  const [file, setFile] = useState<any>();
  const {t, i18n} = useTranslation()
  const [selectedComplaintImages, setSelectedComplaintImages] = useState<any>([]);


  const Complaintform = useFormik<AddComplaintDTO>({
    initialValues: new AddComplaintDTO(),
    validateOnChange: true,
    onSubmit: (values) => {
      const formData = new FormData();
      formData.append("attachments[]", file);
      formData.append("description", values.description);
      formData.append("type", values.type);
      createComplaint(formData);
    },
  });

  const ComplaintformEdit = useFormik<AddComplaintDTO>({
    initialValues: new AddComplaintDTO(),
    validateOnChange: true,
    onSubmit: (values) => {
      const formData = new FormData();
      formData.append("attachments[]", file === undefined ? values.attachments[0]: file);
      formData.append("description", values.description);
      formData.append("type", values.type);
      UpdateComplaint(id, formData);
      setShowEdit(false);
    },
  });

  function handleChange(event: any) {
    setFile(event.target.files[0]);
    const files = Array.from(event.target.files);
    setSelectedComplaintImages(files.map((file:any) => URL.createObjectURL(file)));
  }

  const ShowModal = (rowData: any) => {
    setShowEdit(true);
    ComplaintformEdit.setValues({
        id : rowData.id,
        type: rowData.type,
        description: rowData.description,
        attachments: rowData.attachments
    });
    setId(rowData.id);
    console.log(rowData.attachments[0])
  };

  const GetData = () => {
    getComplaint().then((res: any) => {
      if (res !== undefined) {
        setComplaint(res.data);
      }
    });
  };
  useEffect(() => {
    setLoading(true);
    GetData();
    getComplaintDefinitions().then((res) => {
      setTypes(res.data?.types);
      setStatus(res.data?.status);
      setLoading(false);
    });
  }, []);
  const BodyTemplate = (rowData: any) => {
    return (
      <div className="gap-3">
        {UPDATE_COMPLAINTS()?<i
          className="pi pi-bold pi-pencil"
          style={{
            fontSize: "1.2rem",
            color: "slateblue",
            padding: "7px",
            cursor: "pointer",
          }}
          onClick={() => ShowModal(rowData)}
        ></i>:<></>}
      </div>
    );
  };
  const statusBodyTemplate = (rowData: any) => {
    return (
      <Tag
        value={rowData.status}
        style={
          rowData.status === "PENDING"
            ? { backgroundColor: "#ff8000" }
            : rowData.status === "IN_PROGRESS"
            ? { backgroundColor: "#0000ff" }
            : rowData.status === "UNRESOLVED"
            ? { backgroundColor: "#ff0000" }
            : { backgroundColor: "#294B29" }
        }
        rounded
      ></Tag>
    );
  };
  return (
    <div>
      {
        <div className="card p-5">
          <div>
            <Dialog
              header="Edit Complaint"
              visible={showEdit}
              style={{ width: "40vw" }}
              onHide={() => setShowEdit(false)}
              footer={
                <>
                  <div>
                    <Button
                      label={t("save")}
                      severity="danger"
                      size="small"
                      onClick={() => ComplaintformEdit.handleSubmit()}
                      className="mt-4"
                    ></Button>
                    <Button
                      label={t("cancel")}
                      severity="danger"
                      outlined
                      size="small"
                      onClick={() => setShowEdit(false)}
                      className="mt-4"
                    ></Button>
                  </div>
                </>
              }
            >
              <div className="flex  gap-2">
                <div className="">
                  <label className="mb-2" htmlFor="Firstname">
                    {" "}
                    {t("complaintType")}{" "}
                  </label>
                  <Dropdown
                    value={ComplaintformEdit.values.type}
                    onChange={(e) =>
                      ComplaintformEdit.setFieldValue("type", e.value)
                    }
                    options={types}
                    optionLabel="type"
                    optionValue="type"
                    placeholder= {t("complaintType")}
                    className="w-full"
                  />
                </div>
                <div className="flex-none">
                  <label className="" htmlFor="Lastname">
                    {" "}
                    {t('description')}{" "}
                  </label>
                  <InputText
                    placeholder={t('description')}
                    value={ComplaintformEdit.values.description}
                    onChange={ComplaintformEdit.handleChange}
                    name="description"
                    className="w-full"
                  />
                </div>
              </div>
              <div className="flex-none">
                <label className="" htmlFor="Lastname">
                  {" "}
                  {t('attachments')}{" "}
                </label>
                <FileUpload onChange={handleChange} name=""
                 path={ComplaintformEdit.values.attachments[0] as any}
                 selectImage={selectedComplaintImages}
                 />
              </div>
            </Dialog>
          </div>

          <TabView>
            <TabPanel header={t('allcomplaints')}>
              <DataTable
                value={Complaint}
                stripedRows
                showGridlines
                className=" p-0"
                tableStyle={{ minWidth: "50rem" }}
              >
                <Column field="type" header={t('complaintType')}></Column>
                <Column field="description" header={t('description')}></Column>
                <Column
                  field="attachments.[0]"
                  header={t('attachments')}
                  body={(rowData: any) =>
                    rowData.attachments && rowData.attachments.length > 0 ? (
                      <img
                        src={rowData.attachments[0]}
                        style={{ width: "150px", height: "100px" }}
                        alt="Attachment"
                      />
                    ) : (
                      <span>No attachments</span>
                    )
                  }
                />
                <Column
                  field="status"
                  header={t("status")}
                  body={statusBodyTemplate}
                ></Column>
                <Column field="created_at" header={t("date")}></Column>
                <Column field="" header={t("actions")} body={BodyTemplate}></Column>
              </DataTable>
            </TabPanel>
            { CREATE_COMPLAINTS() ?<TabPanel header={t('addcomplaint')}>
              <form onSubmit={Complaintform.handleSubmit}>
                <div className=" mt-2">
                  <div className="flex  gap-4">
                    <div className="flex-none">
                      <label className="mb-2" htmlFor="Firstname">
                        {" "}
                        {t('complaintType')}{" "}
                      </label>
                      <Dropdown
                        value={Complaintform.values.type}
                        onChange={(e) =>
                          Complaintform.setFieldValue("type", e.value)
                        }
                        options={types}
                        optionLabel="type"
                        optionValue="type"
                        placeholder={t('complaintType')}
                        className="w-full"
                      />
                    </div>
                    <div className="flex-none">
                      <label className="mb-2" htmlFor="Lastname">
                        {" "}
                        {t('description')}{" "}
                      </label>
                      <InputText
                        placeholder={t('description')}
                        value={Complaintform.values.description}
                        onChange={Complaintform.handleChange}
                        name="description"
                        className="w-full"
                      />
                    </div>
                  </div>
                  <div className=" mt-6">
                    <div className="md:col-6 lg:col-6 overflow-hidden">
                      <FileUpload onChange={handleChange} name=""  selectImage={selectedComplaintImages}/>
                    </div>
                  </div>
                  <Button
                    className="mt-4"
                    label={t('sendcomplaint')}
                    severity="danger"
                    outlined
                    size="small"
                    icon="pi pi-check"
                    type="submit"
                  />
                </div>
              </form>
            </TabPanel>:<></>}
          </TabView>
        </div>
      }
    </div>
  );
};

export default Complaint;
