"use client"
import React, { useState, useEffect, useRef } from 'react';
import { DataView, DataViewLayoutOptions } from 'primereact/dataview';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import './detailes.css';
import { changeOrderStatus, showOrder } from '../../../Api/Services';
import { useParams } from 'next/navigation';
import { Tag } from 'primereact/tag';
import { Card } from 'primereact/card';
import { Toast } from 'primereact/toast';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { useTranslation } from 'react-i18next';
import { UPDATE_ORDERS } from '@/permissions/permissions';

const DataViewDemo = () => {
    const [sortKey, setSortKey] = useState<any>(null);
    const [sortOrder, setSortOrder] = useState<any>();
    const [Order, setOrder] = useState<any>();
    const [OrderStatus, setOrderStatus] = useState<any>();
    const [selectedStatus, setSelectedStatus] = useState<any>();
    const [rowClick, setRowClick] = useState(true);
     const params = useParams()
     const {t, i18n} = useTranslation()

      useEffect(()=>{
        showOrder(params.id).then((o:any)=> 
        {setOrder(o.data.order_items)
        setOrderStatus(o.data) as any
        })

      },[]) 
    const onSortChange = (event:any) => {
        const value = event.value;

        if (value.indexOf('!') === 0) {
            setSortOrder(-1);
            setSortKey(value);
        }
        else {
            setSortOrder(1);
            setSortKey(value);
        }
    }
    const statusOptions = OrderStatus?.next_status?.map((status:any) => ({
        label: status,
        value: status
      })) || [];
    const renderListItem = (data:any) => {
        return (
            <div className="col-12" style={{ color: 'GrayText' }}>
            <div className="product-list-item">
            <img src={`${data.subProduct?.product?.images}`}  alt={data.name} />
                <div className="product-list-detail">
                    <div className="product-name mt-3">{data.subProduct?.product_title}</div>
                    <div className="product-description">{data.subProduct.attribute_text_style}</div>
                        <div className="text-bold">Price: {data.price} $</div>
                        <div className="product-quantity">Quantity : {data.quantity}</div>
                </div>
                <div className="product-list-action">
                    <div className="product-description">SKU: {data.subProduct?.sku}</div>
                    <div className="product-description">status: {data.status}</div>

                </div>
            </div>
        </div>
        
        );
    }
    const itemTemplate = (product :any, layout:any) => {
        if (!product) {
            return;
        }

        if (layout === 'list')
            return renderListItem(product);
    }
    const SubmitStatus = () =>{
        let Productarray: any[] = [];
        Productarray.push({
          id: Order.map((order:any)=> order.subProduct.id),
          status: selectedStatus.status
        });

       let data = {
        order_code : params.id,
        sub_products:selectedStatus?.map((s:any)=> s.subProduct.id)
       }
       changeOrderStatus(data)

    }
    return (
        <div className="dataview-demo">
            <div className="card mt-3">
                  <DataTable
                  value={Order}
                  stripedRows
                  showGridlines
                  tableStyle={{ minWidth: "50rem" }}
                  selectionMode={'radiobutton'}
                  selection={selectedStatus} onSelectionChange={(e) => setSelectedStatus(e.value)} 
                >
                <Column selectionMode="multiple" header={t("selectProducts")} headerStyle={{ width: '3rem' }}></Column>
                  <Column
                    field="subProduct.product_title"
                    header={t('name')}
                  ></Column>
                  <Column
                    field="subProduct.attribute_text_style"
                    header={t("attribute")}
                  ></Column>
                   <Column
                    field="subProduct.sku"
                    header={t("sku")}
                  ></Column>
                  <Column field="quantity" header={t("quantity")}></Column>
                  <Column field="price" header={t("price")}></Column>
                  <Column
                    field="amount"
                    header={t("amount")}
                    body={(rowData: any) => rowData.price * rowData.quantity}
                  ></Column>
                  <Column field="status" header={t("status")}></Column>
                </DataTable>
             <div className='card mt-3'>
             <Card>
                <h3 className='mb-4'>{t("sendProductsmsg")}</h3>
{              UPDATE_ORDERS()?  <Button onClick={ SubmitStatus } severity="info"  className='' label={t("sendProducts")}></Button>:<></>
}         </Card>

            </div>
            </div>

        </div>
    );
}
export default DataViewDemo