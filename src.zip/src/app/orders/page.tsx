"use client"
import { getOrder } from '../../Api/Services';
import axios, { AxiosResponse } from 'axios';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { FilterMatchMode } from "primereact/api";
import { Button } from "primereact/button";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { InputText } from "primereact/inputtext";
import { Tag } from "primereact/tag";
import React from "react";
import { useTranslation } from 'react-i18next';


const Order = () => {
    const [filters, setFilters] = React.useState<any>();
    const [loading, setLoading] = React.useState(false);
    const [globalFilterValue, setGlobalFilterValue] = React.useState<any>();
    const [orderList,setOrderlist]= React.useState<any>();
    const {t, i18n} = useTranslation()

    const router = useRouter();
    router.push('/orders')

     const GetOrder = async () =>{
        setLoading(true)
        try {
            getOrder().then((res)=>setOrderlist(res.data))
        }
            catch(e){
             console.error(e)
            }
        setLoading(false)
     }
    const statusBodyTemplate = (product: any) => {
        return <Tag value={product.status} severity={getSeverity(product)}></Tag>;
    };
    const initFilters = () => {
        setFilters({
            global: { value: null, matchMode: FilterMatchMode.CONTAINS },
        });
        setGlobalFilterValue('');
    };
    const onGlobalFilterChange = (e: any) => {
        const value = e.target.value;
        let _filters = { ...filters };

        _filters['global'].value = value;

        setFilters(_filters);
        setGlobalFilterValue(value);
    };
    const clearFilter = () => {
        initFilters();
    };
    React.useEffect(()=>{
        GetOrder()
    },[])
    const getSeverity = (product: any) => {
        switch (product.inventoryStatus) {
            case '':
                return 'success';

            case 'PENDING':
                return 'warning';

            case '':
                return 'danger';

            default:
                return null;
        }
    };
    const DetailsTemplate = (product: any) => {
        return (
            <Link href={`/orders/${product.code}`}>
                <i className="pi pi-info-circle"  ></i>
            </Link>
        )

    }
    const header = (
        <div className="flex flex-wrap gap-3 align-items-center">
        <div>
        </div>
        <span className="p-input-icon-left m-3"  style={{ marginLeft: 'auto' }}>
          <InputText
            value={globalFilterValue}
            onChange={onGlobalFilterChange}
            placeholder={t('search')}
          />
        </span>
      </div>
    );

    return (
        <>
            <div className="card mt-5">
                <DataTable value={orderList} header={header} globalFilterFields={['name', 'price', 'category', 'balance', 'status']} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]}
                    filters={filters} paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink"
                    tableStyle={{ minWidth: '60rem' }} >
                    <Column field="code" header={t('code')}></Column>
                    <Column field="delivery_fee" header={t('deliveryfee')}></Column>
                    <Column field="total_amount" header={t('amount')}></Column>
                    <Column field="due_date" header={t('dueDate')} ></Column>
                    <Column field="status" header={t("status")} body={statusBodyTemplate}></Column>
                    <Column field="total_volume" header={t("totalVolume")} ></Column>
                    <Column field="total_weight" header={t("totalWeight")} ></Column>
                    <Column header={t("details")} body={DetailsTemplate}></Column>
                </DataTable>
            </div>
        </>
    )
}

export default Order;
