"use client"
import { resetPassword } from '../../Api/Services';
import { EyeFilledIcon } from '@/components/icons/EyeFilledIcon';
import { EyeSlashFilledIcon } from '@/components/icons/EyeSlashFilledIcon';
import Section from '@/components/layout/Section';
import { Button, Input, Spinner } from '@nextui-org/react';
import { useFormik } from 'formik';
import Link from 'next/link';
import React from 'react'
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';

type Props = {}

const ResetPassword = (props: Props) => {
  const [isVisible, setIsVisible] = React.useState(false);
  const toggleVisibility = () => setIsVisible(!isVisible);
  const {t, i18n} = useTranslation()

  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
      code: '',
      password_confirmation: '',
    },
    validationSchema: Yup.object({
      email: Yup.string().email('Invalid email format').required('Email is required'),
      password: Yup.string().required('password is required').matches(
        /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,}$/,
        'Password must be at least 8 characters long and contain one uppercase letter and one or more symbols'
      ),
      password_confirmation: Yup.string().oneOf([Yup.ref('password')], 'Passwords must match'),
    }),
    onSubmit: async (values, { setSubmitting }) => {
      await  resetPassword(values);
      setSubmitting(false);
    },
  });

  return (
    <Section className='flex justify-center align-center items-center'>
      <form onSubmit={formik.handleSubmit} className="flex flex-col gap-5 w-1/2">
        <img
          width={138}
          height={57}
          className="max-h-16 text-center w-full object-contain"
          alt="Picture of the author"
          src={'/assets/images/logoWithText.png'}
        />
        <h1 className='font-bold text-lg text-center mb-5'>{t('resetPassword')}</h1>
        <Input
          type="email"
          name='email'
          radius='sm'
          size='sm'
          variant='bordered'
          classNames={{
            errorMessage: "text-start"
          }}
          placeholder= {t('email')}
          defaultValue={formik.values.email}
          isInvalid={formik.touched.email}
          errorMessage={formik.touched.email && formik.errors.email}
          onChange={formik.handleChange}
        />
        <Input
          radius='sm'
          size='sm'
          name='password'
          variant='bordered'
          classNames={{
            base: "col-span-1",
            errorMessage: "text-start"
          }}
          placeholder={t('password')}
          defaultValue={formik.values.password}
          isInvalid={formik.touched.password}
          errorMessage={formik.errors.password}
          endContent={
            <div className="focus:outline-none cursor-pointer" onClick={toggleVisibility}>
              {isVisible ? (
                <EyeSlashFilledIcon className="text-2xl text-default-400 pointer-events-none" />
              ) : (
                <EyeFilledIcon className="text-2xl text-default-400 pointer-events-none" />
              )}
            </div>
          }
          type={isVisible ? "text" : "password"}
          onChange={formik.handleChange}
        />
        <Input
          radius='sm'
          size='sm'
          name='password_confirmation'
          variant='bordered'
          classNames={{
            base: "col-span-1",
            errorMessage: "text-start"
          }}
          placeholder={t('passwordConfirm')}
          defaultValue={formik.values.password_confirmation}
          isInvalid={formik.touched.password_confirmation}
          errorMessage={formik.errors.password_confirmation}
          onChange={formik.handleChange}
          endContent={
            <div className="focus:outline-none cursor-pointer" onClick={toggleVisibility}>
              {isVisible ? (
                <EyeSlashFilledIcon className="text-2xl text-default-400 pointer-events-none" />
              ) : (
                <EyeFilledIcon className="text-2xl text-default-400 pointer-events-none" />
              )}
            </div>
          }
          type={isVisible ? "text" : "password"}
        />
        <Button type='submit' isDisabled={formik.isSubmitting} color='primary' size='lg' radius='sm'>
          {formik.isSubmitting ? <Spinner color='white' size='sm' /> : t('send')}
        </Button>
      </form>
    </Section>
  )
}

export default ResetPassword
