import AppWebsiteVisits from "@/components/layout/ApexChart";
import AppWidgetSummary from "@/components/layout/Summery";
import AppUsersVisits from "@/components/layout/CircleChart";

export default function Home() {
  return (
    <div className="h-[100%]">
      <div className="grid lg:grid-cols-3 md:grid-cols-1 mt-5 gap-6 mx-0">
        <AppWidgetSummary
          title="Weekly Sales"
          total={0}
          color="success"
          icon={<img src="/assets/images/glass/ic_glass_bag.png" />}
        />

        <AppWidgetSummary
          title="New Users"
          total={0}
          color="info"
          icon={<img src="/assets/images/glass/ic_glass_users.png" />}
        />

        <AppWidgetSummary
          title="Weekly Orders"
          total={0}
          color="warning"
          icon={<img src="/assets/images/glass/ic_glass_buy.png" />}
        />
      </div>

      <div className="grid lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 gap-6 mt-5 mx-0">
        <AppWebsiteVisits
          title="App Website Visits"
          subheader="(+0%) than last year"
        />

        <AppUsersVisits
          title="App Users Visits"
          subheader="(+0%) than last year"
        />
      </div>
    </div>
  );
}
