'use client'
import type { Metadata } from 'next'
import { Montserrat } from 'next/font/google';
import "./globals.css";
import '../styles/app.scss';
import '../styles/fileUploader.scss';
import '../styles/loginForm.scss';
import Sidebar from '@/components/layout/sidebar';
import { Providers } from './providers';
import Head from 'next/head';
import AuthRedirected from './authRedirected';
import Header from '@/components/layout/header';
import { Bounce, ToastContainer } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
import '../i18n'
import * as React from 'react';
import i18n from '../i18n';
import useIsRTL from '@/components/RTL';

const montserrat = Montserrat({ subsets: ['latin'] })
// export const metadata: Metadata = {
//   title: 'doshtu',
// }

export default function RootLayout({
  children,
}: {
  children: React.ReactNode,
}) {
  const isRTL = useIsRTL();

  return (
    <html style={{height:'100vh'}} dir={isRTL ? "rtl" : "ltr"}>
      <Head>
        <link rel="icon" href="/assets/images/logo.svg" type="image/x-icon" />
        <title>Doshto</title>
      </Head>

      <body className={`${montserrat.className}`} style={{ backgroundColor: '#f5f4f4 !important', height: '100%'}}>

        <ToastContainer
          position="top-right"
          autoClose={5000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
          transition={Bounce}
        />
        <ToastContainer />

        <Providers>
          <AuthRedirected>
            <div className="flex custom-background min-h-[100vh]">
              <Sidebar />

              <div className="w-full mx-4 p-3">
                <Header />
                <div className="!m-0">{children}</div>
              </div>
            </div>
          </AuthRedirected>
        </Providers>
      </body>
    </html>
  )
}
