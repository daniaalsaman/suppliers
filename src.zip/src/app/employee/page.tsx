"use client";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import { useFormik } from "formik";
import { InputNumber } from "primereact/inputnumber";
import { InputText } from "primereact/inputtext";
import { InputSwitch } from "primereact/inputswitch";
import { ConfirmDialog, confirmDialog } from "primereact/confirmdialog";
import { Dropdown } from "primereact/dropdown";
import {
  Roles,
  EmployeeInfo,
  DetailsEmployee,
  DeleteEmplyee,
  UpdateEmployee,
  AddEmployee,
} from "@/Api/Services";
import { EmployeeDTO } from "@/modules/supplier.modules";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchCities,
  fetchCountries,
  fetchMunicipalities,
  fetchNeighborhoods,
} from "@/lib/features/core/address";
import CountrySelect from "@/components/layout/countrySelect";
import CitySelect from "@/components/layout/citySelect";
import MunicipalitySelect from "@/components/layout/municipalitySelect";
import { useTranslation } from "react-i18next";
import { CREATE_EMPLOYEES, DELETE_EMPLOYEES, UPDATE_EMPLOYEES } from "@/permissions/permissions";
import { FilterMatchMode } from "primereact/api";

const Employee = () => {
  const dispatch = useDispatch<any>();
  const { countries, cities, municipalities, neighborhoods } = useSelector(
    (state: any) => state.address
  );
  const [EmployeeList, setEmployeeList] = useState<any>();
  const [show, setShow] = useState<boolean>(false);
  const [showEdit, setShowEdit] = useState<boolean>(false);
  const [rowIdForEdit, setRowIdForEdit] = useState<number>();
  const [RolesList, setRolesList] = useState<any>();
  const [country, setCountry] = useState<any>();
  const [city, setCity] = useState<any>();
  const [municipality, setMunicipality] = useState<any>();
  const {t, i18n} = useTranslation()
  const [globalFilterValue, setGlobalFilterValue] = useState("");
  const [filters, setFilters] = useState({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    first_name: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    last_name: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    email: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    type: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    status: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    created_at: { value: null, matchMode: FilterMatchMode.DATE_IS },
  });
  const getEmployeeList = () => {
    EmployeeInfo().then((res) => {
        setEmployeeList(res.data);
    });
    Roles().then((res) => setRolesList(res.data));
  };
  const options = RolesList?.map((role: any) => ({
    label: role,
    value: role,
  }));
  const statusOptions = [
    { label: "ACTIVE", value: "ACTIVE" },
    { label: "BLOCKED", value: "BLOCKED" },
  ];
  const Employeeform = useFormik<EmployeeDTO>({
    initialValues: new EmployeeDTO(),
    validateOnChange: true,
    onSubmit: () => {
      AddEmployee(Employeeform.values);
      setShow(false);
    },
  });

  const EmployeeformEdit = useFormik<EmployeeDTO>({
    initialValues: new EmployeeDTO(),
    validateOnChange: true,
    onSubmit: () => {
      UpdateEmployee(EmployeeformEdit.values, rowIdForEdit);
      setShowEdit(false);
    },
  });

  const ShowEmployee = async (id: number) => {
    setShowEdit(true);
    const data = await DetailsEmployee(id);
    EmployeeformEdit.setValues(data?.data);
    setRowIdForEdit(id);
  };
  useEffect(() => {
    getEmployeeList();
    const fetchData = async () => {
      await dispatch(fetchCountries());
    };
    fetchData();
  }, []);
  const selectCityByCountry = async (CountryId: number) => {
    await dispatch(fetchCities(CountryId));
    setCountry(CountryId);
  };
  const selectMunicipalityByCity = async (cityId: number) => {
    await dispatch(fetchMunicipalities(cityId));
    setCity(cityId);
  };
  const selectNeighborhoodByMunicipality = async (municipalitiyId: number) => {
    await dispatch(fetchNeighborhoods(municipalitiyId));
    setMunicipality(municipalitiyId);
  };
  const DeleteEmployee = (id: number) => {
    DeleteEmplyee(id);
  };
  const confirm = (id: number) => {
    confirmDialog({
      message: t('deleteEmployeemsg'),
      header: t('deleteconfirm'),
      icon: "pi pi-info-circle",
      defaultFocus: "reject",
      acceptClassName: "p-button-danger py-2",
      rejectClassName: "p-button-outlined py-2",
      acceptLabel: t('delete'),
      rejectLabel: t('cancel'),
      accept: () => DeleteEmployee(id),
    });
  };
  const onGlobalFilterChange = (e: any) => {
    const value = e.target.value;
    let _filters = { ...filters };

    _filters["global"].value = value;

    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  const renderHeader = () => {
    return (
      <div className="flex flex-wrap gap-3 align-items-center">
        <div>
        {CREATE_EMPLOYEES()? 
        <Button
        label={t('addemployee')}
        onClick={() => setShow(true)}
        size="small"
        severity="danger"
        className="mt-4 ml-5"
      ></Button>:<></>}
        </div>
        <span className="p-input-icon-left m-3"  style={{ marginLeft: 'auto' }}>
          <InputText
            value={globalFilterValue}
            onChange={onGlobalFilterChange}
            placeholder={t('search')}
          />
        </span>
      </div>
    );
  };
  const header = renderHeader();

  const BodyTemplate = (rowData: any) => {
    return (
      <div className="gap-3">
       { UPDATE_EMPLOYEES() ? <i
          className="pi pi-bold pi-pencil"
          onClick={() => ShowEmployee(rowData?.id)}
          style={{
            fontSize: "1.2rem",
            color: "slateblue",
            padding: "7px",
            cursor: "pointer",
          }}
        ></i> :<></>}
       {DELETE_EMPLOYEES() ? <i
          className="pi pi-bold pi-trash"
          onClick={() => confirm(rowData?.id)}
          style={{ fontSize: "1.2rem", color: "red", cursor: "pointer" }}
        ></i>:<></>}
      </div>
    );
  };
  return (
    <div>
      <ConfirmDialog />
      <DataTable
        value={EmployeeList}
        stripedRows
        showGridlines
        className=" p-5"
        tableStyle={{ minWidth: "50rem" }}
        header={header}
        filters={filters}
        emptyMessage={t('tableMsg')}
      >
        <Column field="first_name" header={t('employeeName')}></Column>
        <Column field="email" header={t('email')}></Column>
        <Column field="type" header={t('employeeType')}></Column>
        <Column field="status" header={t('status')}></Column>
        <Column field="address.city.name" header={t('city')}></Column>
        <Column field="authorizations.role" header={t('role')}></Column>
        <Column field="employee_at.name" header={t('name')}></Column>
        <Column field="" header={t('actions')} body={BodyTemplate}></Column>
      </DataTable>
      <></>
      <Dialog
        header={t('addemployee')}
        visible={show}
        style={{ width: "50vw" }}
        onHide={() => setShow(false)}
        footer={
          <>
            <div>
              <Button
                label={t('save')}
                severity="info"
                size="small"
                onClick={() => Employeeform.handleSubmit()}
                className="mt-4"
              ></Button>
              <Button
                label={t('cancel')}
                severity="danger"
                outlined
                size="small"
                onClick={() => setShow(false)}
                className="mt-4"
              ></Button>
            </div>
          </>
        }
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('firstname')}{" "}
            </label></div>
            <InputText
              placeholder={t('firstname')}
              name="first_name"
              value={Employeeform?.values?.first_name}
              onChange={(e) =>
                Employeeform.setFieldValue("first_name", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4">
           <div> <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('lastname')}{" "}
            </label></div>
            <InputText
              placeholder={t('lastname')}
              name="last_name"
              value={Employeeform?.values?.last_name}
              onChange={(e) =>
                Employeeform.setFieldValue("last_name", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4">
            <div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('email')}{" "}
            </label></div>
            <InputText
              placeholder= {t('email')}
              name="email"
              value={Employeeform?.values?.email}
              onChange={(e) =>
                Employeeform.setFieldValue("email", e.target.value)
              }
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
          <div><div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('password')}{" "}
            </label></div>
            <InputText
              placeholder={t('password')}
              name="password"
              value={Employeeform?.values?.password}
              onChange={(e) =>
                Employeeform.setFieldValue("password", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4">
           <div> <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('status')}{" "}
            </label></div>
             <Dropdown
                  value={Employeeform?.values?.status}
                  onChange={(e) =>
                    Employeeform.setFieldValue("status", e.target.value)
                  }
                  options={statusOptions}
                  optionLabel="label"
                  optionValue="value"
                  name="status"
                  placeholder={t('status')}
                  className="w-full"
                />
          </div>
          <div><div>
          <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('country')}{" "}
            </label></div>
            <CountrySelect
              className="col-span-6"
              placeholder={t('selectCountry')}
              countries={countries}
              formik={Employeeform.handleChange}
              selectCityByCountry={selectCityByCountry}
            />
          </div>
          <div><div>
          <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('city')}{" "}
            </label></div>
            <CitySelect
              className="col-span-6"
              placeholder={t('selectCity')}
              cities={cities.data}
              formik={Employeeform}
              selectMunicipalityByCity={selectMunicipalityByCity}
            />
          </div>
          <div><div>
          <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('municipality')}{" "}
            </label>
            <MunicipalitySelect
              className="col-span-6"
              municipalities={municipalities.data}
              formik={Employeeform}
              selectedneighborhoods={selectNeighborhoodByMunicipality}
            />
          </div></div>
          <div><div>
          <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('neighborhood')}{" "}
            </label></div>
            <div>
            <Dropdown
              value={Employeeform.values.neighborhood_id}
              onChange={Employeeform.handleChange}
              options={neighborhoods.data}
              optionLabel="name"
              placeholder={t('selectNeighborhood')}
              filter
              className="w-full"
            />
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
        <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('street')}{" "}
            </label></div>
            <InputText
              placeholder={t('street')}
              name="street"
              value={Employeeform?.values?.street}
              onChange={(e) =>
                Employeeform.setFieldValue("street", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('building')}{" "}
            </label></div>
            <InputText
              placeholder={t('building')}
              name="building"
              value={Employeeform?.values?.building}
              onChange={(e) =>
                Employeeform.setFieldValue("building", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div><div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('floor')}{" "}
            </label></div>
            <InputText
              placeholder={t('floor')}
              name="floor"
              value={Employeeform?.values?.floor}
              onChange={(e) =>
                Employeeform.setFieldValue("floor", e.target.value)
              }
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
        <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('apartment')}{" "}
            </label></div>
            <InputText
              placeholder={t('apartment')}
              name="apartment"
              value={Employeeform?.values?.apartment}
              onChange={(e) =>
                Employeeform.setFieldValue("apartment", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('role')}{" "}
            </label></div>
            <Dropdown
              value={Employeeform?.values?.role}
              onChange={(e) =>
                Employeeform.setFieldValue("role", e.target.value)
              }
              options={options}
              optionLabel="label"
              optionValue="value"
              name="role"
              placeholder={t('role')}
              className="w-full"
            />
          </div>
          <div><div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('postalCode')}{" "}
            </label></div>
            <InputText
              placeholder={t('postalCode')}
              name="postal_code"
              value={Employeeform?.values?.postal_code}
              onChange={(e) =>
                Employeeform.setFieldValue("postal_code", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div><div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('details')}{" "}
            </label></div>
            <InputText
              placeholder={t('details')}
              name="more_details"
              value={Employeeform?.values?.more_details}
              onChange={(e) =>
                Employeeform.setFieldValue("more_details", e.target.value)
              }
              className="w-full"
            />
          </div>
        </div>
      </Dialog>
      <></>
      <Dialog
        header={t('editEmployee')}
        visible={showEdit}
        style={{ width: "50vw" }}
        onHide={() => setShowEdit(false)}
        footer={
          <>
            <div>
              <Button
                label={t('save')}
                severity="info"
                size="small"
                onClick={() => EmployeeformEdit.handleSubmit()}
                className="mt-4"
              ></Button>
              <Button
                label={t('cancel')}
                severity="danger"
                outlined
                size="small"
                onClick={() => setShowEdit(false)}
                className="mt-4"
              ></Button>
            </div>
          </>
        }
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div><div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('firstname')}{" "}
            </label></div>
            <InputText
              placeholder={t('firstname')}
              name="first_name"
              value={EmployeeformEdit?.values?.first_name}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("first_name", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('lastname')}{" "}
            </label></div>
            <InputText
              placeholder={t('lastname')}
              name="last_name"
              value={EmployeeformEdit?.values?.last_name}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("last_name", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('email')}{" "}
            </label></div>
            <InputText
              placeholder={t('email')}
              name="email"
              value={EmployeeformEdit?.values?.email}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("email", e.target.value)
              }
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
          <div><div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('password')}{" "}
            </label></div>
            <InputText
              placeholder={t('password')}
              name="password"
              value={EmployeeformEdit?.values?.password}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("password", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('status')}{" "}
            </label></div>
               <Dropdown
                  value={EmployeeformEdit?.values?.status}
                  onChange={(e) =>
                    EmployeeformEdit.setFieldValue("status", e.target.value)
                  }
                  options={statusOptions}
                  optionLabel="label"
                  optionValue="value"
                  name="status"
                  placeholder={t('status')}
                  className="w-full"
                />
          </div>
          <div><div>
          <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('country')}{" "}
            </label></div>
            <CountrySelect
              className="col-span-6"
              placeholder="Select a Country"
              countries={countries}
              formik={EmployeeformEdit.handleChange}
              selectCityByCountry={selectCityByCountry}
            />
          </div>
          <div><div>
          <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('city')}{" "}
            </label></div>
            <CitySelect
              className="col-span-6"
              placeholder="Select a City"
              cities={cities.data}
              formik={EmployeeformEdit}
              selectMunicipalityByCity={selectMunicipalityByCity}
            />
          </div>
          <div><div>
          <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('municipality')}{" "}
            </label></div>
            <MunicipalitySelect
              className="col-span-6"
              municipalities={municipalities.data}
              formik={EmployeeformEdit}
              selectedneighborhoods={selectNeighborhoodByMunicipality}
            />
          </div>
          <div><div>
          <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('neighborhood')}{" "}
            </label></div>
            <Dropdown
              value={EmployeeformEdit.values.neighborhood_id}
              aria-placeholder="neighborhoods"
              onChange={EmployeeformEdit.handleChange}
              options={neighborhoods.data}
              optionLabel="name"
              placeholder={t('selectNeighborhood')}
              filter
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
        <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('street')}{" "}
            </label></div>
            <InputText
              placeholder={t('street')}
              name="street"
              value={EmployeeformEdit?.values?.street}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("street", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('building')}{" "}
            </label></div>
            <InputText
              placeholder={t('building')}
              name="building"
              value={EmployeeformEdit?.values?.building}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("building", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div><div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('floor')}{" "}
            </label></div>
            <InputText
              placeholder={t('floor')}
              name="floor"
              value={EmployeeformEdit?.values?.floor}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("floor", e.target.value)
              }
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
        <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('apartment')}{" "}
            </label></div>
            <InputText
              placeholder={t('apartment')}
              name="apartment"
              value={EmployeeformEdit?.values?.apartment}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("apartment", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4"><div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('role')}{" "}
            </label></div>
            <Dropdown
              value={EmployeeformEdit?.values?.role}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("role", e.target.value)
              }
              options={options}
              optionLabel="label"
              optionValue="value"
              name="role"
              placeholder={t('role')}
              className="w-full"
            />
          </div>
          <div><div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('postalCode')}{" "}
            </label></div>
            <InputText
              placeholder={t('postalCode')}
              name="postal_code"
              value={EmployeeformEdit?.values?.postal_code}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("postal_code", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div><div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('moreDetails')}{" "}
            </label></div>
            <InputText
              placeholder={t('moreDetails')}
              name="more_details"
              value={EmployeeformEdit?.values?.more_details}
              onChange={(e) =>
                EmployeeformEdit.setFieldValue("more_details", e.target.value)
              }
              className="w-full"
            />
          </div>
        </div>
      </Dialog>
    </div>
  );
};

export default Employee;
