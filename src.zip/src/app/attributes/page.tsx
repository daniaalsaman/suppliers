"use client";

import React, { useEffect, useState } from "react";

import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { getAttributes } from "../../Api/Services";
import { Tag } from "primereact/tag";
import { useTranslation } from "react-i18next";

export default function Attrs() {
  const [attributesVal, setAttributesVal] = useState<any>(null);
  const [expandedRows, setExpandedRows] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const {t, i18n} = useTranslation()
  const isRTL = i18n.language === "ar";

  useEffect(() => {
    getAttributes()
      .then((res: any) => {
        setAttributesVal(res.data.attributes);
      })
      .catch((error: any) => {
        console.error("Error fetching attributes:", error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  const allowExpansion = (rowData: any) => {
    return rowData.values.length > 0;
  };
  const rowExpansionTemplate = (data: any) => {
    return (
      (
        <div className="p-3">
          <div className="card flex flex-wrap justify-content-center gap-2 mt-4">
            {data.values.map((val: any) => (
              <Tag value={val.value} severity="info" rounded></Tag>
            ))}
          </div>
        </div>
      )
    );
  };
  if (loading) {
    return <div>Loading...</div>;
  }

  if (!attributesVal || attributesVal.length === 0) {
    return <div>No attributes found.</div>;
  }
  return (
    <div className="flex flex-col gap-3 mt-6">
      <DataTable
        value={attributesVal}
        expandedRows={expandedRows}
        onRowToggle={(e) => setExpandedRows(e.data)}
        rowExpansionTemplate={rowExpansionTemplate}
        paginator
        rows={5}
        rowsPerPageOptions={[5, 10, 25, 50]}
        size="normal"
        dataKey="id"
      >
        <Column sortable field="id" header="ID"></Column>
        <Column
          sortable
          field="attribute_name"
          header={t('name')}
        ></Column>
        <Column expander={allowExpansion} header="Details" />
      </DataTable>
    </div>
  );
}
