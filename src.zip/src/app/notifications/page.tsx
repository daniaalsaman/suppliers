"use client"
import React, { useState, useEffect } from 'react';
import { OrderList } from 'primereact/orderlist';
import { MarkNotifications, Notifications } from '@/Api/Services';
import { DataView } from 'primereact/dataview';
import { useTranslation } from 'react-i18next';
export default function BasicDemo() {
    const [notifications, setNotifications] = useState([]);
    const { t, i18n } = useTranslation();
 
    useEffect(() => {
        Notifications().then((data) => setNotifications(data.data));
    }, []);
    const itemTemplate = (item:any) => {
        return (
            <div className="flex flex-wrap p-2 align-items-center gap-3">
                <div className="flex-1 flex flex-column gap-2 xl:mr-8">
                    <span className="font-bold">{item.title}</span>
                    <div className="flex align-items-center gap-2">
                        <i className="pi pi-arrow-circle-right text-sm"></i>
                        <span>{item.description}</span>
                    </div>
                    <div className="flex align-items-center gap-2">
                        <i className="pi pi-megaphone text-sm"></i>
                        <span style={{color:'red'}}>{item.type}</span>
                    </div>
                    <div className="flex align-items-center gap-2">
                        <i className="pi pi-clock text-sm"></i>
                        <span ><span style={{color:'black'}}>{item.is_scheduled === 0 ? 'Not Scheduled' : 'Scheduled'}</span></span>
                    </div>
                </div>
                <span className="font-bold text-900">{item.created_at}</span>
            </div>
        );
    };
    
    return (
        <div className="card mt-5">
            <DataView  value={notifications}  itemTemplate={itemTemplate} header={t("allNotifications")}/>
        </div>
    )
}
        