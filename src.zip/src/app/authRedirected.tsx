"use client"
import LoginPage from '@/components/LoginPage';
import { Spinner } from '@nextui-org/react';
import { headers } from 'next/headers';
import React, { useEffect, useMemo, useState } from 'react'
import { useSelector } from 'react-redux';
import { usePathname } from 'next/navigation'
import ResetPassword from './resetPassword/page';

type Props = { children: React.ReactNode };

const AuthRedirected = ({ children }: Props) => {
  const [isAuth, setIsAuth] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const token = typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('token') : '';
  const pathname = usePathname()
  const isAuthenticated = useMemo(() => {
    return !!token;
  }, [token]);

  useEffect(() => {
    setIsAuth(isAuthenticated);
    setTimeout(() => {
      setIsLoading(false);
    }, 5000);
  }, [isAuthenticated]);

  return (
    <>
      {isAuth ? (
        <>
          {children}
        </>
      ) : isLoading ? (
        <div className='w-screen h-screen flex justify-center items-center'>
          <Spinner size='lg' />
        </div>
      ) : (
        pathname.includes("resetPassword") ?
          <ResetPassword /> :
          <LoginPage />
      )}
    </>
  );
};

export default AuthRedirected;
