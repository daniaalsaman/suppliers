"use client"
import TableSection from "@/components/layout/Table";
import Filter from "@/components/layout/filterSection";
import React, { useEffect, useState } from 'react';
import { FilterDTO, IPagination } from '@/modules/supplier.modules';
import { getProductList  } from '../../Api/Services';
import { useFormik } from "formik";

 function Products() {
  const [products,setProducts] = useState<any>()
  const [pagination, setPagination] = useState<IPagination>();
  const [first, setFirst] = useState(2);
  const [dataFromChild, setDataFromChild] = useState('');
const [SelectedminPrice,setSelectedminPrice] = useState<any>();
const [SelectedmaxPrice,setSelectedmaxPrice] = useState<any>();
const [Selectedcategories,setSelectedcategories] = useState<any>([]);
const [filteredProducts, setFilteredProducts] = useState<any>([]);

  const filterProductFormik = useFormik<FilterDTO>({
    initialValues: new FilterDTO(),
    validateOnChange: true,
    onSubmit: (values) => {
      let selectedCategories = filterProductFormik.values.categories;
      if (filterProductFormik.values.categories!.length > 0) {
        selectedCategories = filterProductFormik.values.categories!.map(
          (cat: any) => cat.id
        );
      } else {
        selectedCategories = [];
      }
      let dataToFilter = {
        // categories: selectedCategories,
        // price: values.price,
        // quantity: values.quantity,
        categories: selectedCategories,
        minPrice: values.minPrice,
        maxPrice: values.maxPrice,
        available: values.available,
        publishedOnStore: values.publishedOnStore,
      };
      // setSelectedPrice(filterProductFormik.values.minPrice);
      setSelectedcategories(filterProductFormik.values.categories);
      // setSelectedquantity(
      //   filterProductFormik.values.available 
      // );
      getProductList(1, undefined, dataToFilter).then((res) => {
        if (res !== undefined) {
            if (res.data.pagination) {
              setPagination(res.pagination);
            }
            setProducts(res.data);
            setFilteredProducts(res.data);
        }
      });
    },
  });

  const handleDataFromChild = (data:any) => {
    setDataFromChild(data);
  };
  const handleminPriceFromChild = (data:any) => {
    setSelectedminPrice(data);
  };
  const handlemaxPriceFromChild = (data:any) => {
    setSelectedmaxPrice(data);
  };
  const handleCategoreyFromChild = (data:any) => {
    setSelectedcategories(data);
  };
  useEffect(() => {
    getProductList(1).then((res)=> setProducts(res.data))
    getProductList(1).then((res)=> setPagination(res.pagination))
},[]
  );
  const OnPageChange = (text: string) => {
    let currentPage = 1;
    switch (text) {
      case "next":
        currentPage = pagination!.current_page + 1;
        break;
      case "prev":
        currentPage = pagination!.current_page - 1;
        break;
      case "first":
        currentPage = 1;
        break;
      case "last":
        currentPage = pagination!.total_pages;
        break;

      default:
    }

    getProductList(currentPage).then((newProducts) => {
    setProducts(newProducts.data);
      setPagination(newProducts!.pagination);
      setFirst(currentPage);
    });
  };
     const SearchFun = ()=>{
      getProductList(1 , dataFromChild).then((res)=> setProducts(res?.data))
    }
    const FilterFun = ()=>{
      let Fdata ={
        categories: Selectedcategories, //array
        minPrice: SelectedminPrice,
        maxPrice: SelectedmaxPrice
      }
      const queryString = new URLSearchParams(Fdata).toString();
      getProductList(1 , dataFromChild , queryString).then((res)=> setProducts(res?.data))
    }
  return (
    <div className="flex flex-col gap-3 mt-3">
      <Filter isshown={true} search={SearchFun} onData={handleDataFromChild}
      onFiltermaxPriceData= {handlemaxPriceFromChild}
      onFilterCategoryData={handleCategoreyFromChild}
      onFilterminPriceData={handleminPriceFromChild}
      FilterSearch={FilterFun} />
      <TableSection OnPageChange={OnPageChange} pagination={pagination} products={products} />
    </div>
  );
}

export default Products;