"use client"
import { showProduct } from '../../../../Api/Services';
import { useParams } from 'next/navigation';
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import React, { useEffect } from "react";
import { useTranslation } from 'react-i18next';
import { Image } from 'primereact/image';


const Details = () => {
  const [loading, setLoading] = React.useState(false);
  const [detailsList, setDetailslist]= React.useState<any>();
  const {t} = useTranslation()
  const params = useParams();

  useEffect(()=>{
    setLoading(true);

    try {
      showProduct(params.id).then((res) => setDetailslist(res.data.subProducts));
    }catch(e){
      console.error(e);
    }

    setLoading(false);
  },[])

  const imageBodyTemplate = (product: any) => {
    return <Image  src={product?.image} alt={product?.image} width="80" height="60" preview />
  };

  return (
    <>
      <div className="card mt-5">
          <DataTable value={detailsList} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink">
            <Column header={t('image')} body={imageBodyTemplate}></Column>
            <Column field="quantity" header={t('quantity')}></Column>
            <Column field="sku" header={t('sku')}></Column>
            <Column field="price" header={t('price')} ></Column>
            <Column field="height" header={t('height')}></Column>
            <Column field="width" header={t('width')} ></Column>
            <Column field="length" header={t('length')} ></Column>
            <Column field="weight" header={t('weight')} ></Column>
          </DataTable>
      </div>
    </>
  )
}

export default Details
