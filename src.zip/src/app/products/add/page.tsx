"use client";
import { Table, TableBody, TableCell, TableColumn, TableHeader, TableRow } from "@nextui-org/react";
import React, { useEffect, useState } from "react";
import Section from "@/components/layout/Section";
import Link from "next/link";
import { Button } from "primereact/button";
import { InputSwitch } from "primereact/inputswitch";
import { InputText } from "primereact/inputtext";
import { InputNumber } from "primereact/inputnumber";
import { Editor, EditorTextChangeEvent } from "primereact/editor";
import { useFormik } from "formik";
import { Dropdown } from "primereact/dropdown";
import * as Yup from "yup";
import { createProduct, getAttributes, getCategories } from "../../../Api/Services";
import { Combination, ProductDTO, SelectAttributesName, Variants } from '@/modules/supplier.modules';
import { Dialog } from "primereact/dialog";
import FileUpload from "@/components/FileUploader";
import { useTranslation } from "react-i18next";
import { Chip } from 'primereact/chip';

type Props = {};

function Add({}: Props) {
  const [selectedCategories, setSelectedCategories] = useState<any>(null);
  const [categories, setCategories] = useState<any>();
  const [attributes, setAttributes] = useState<SelectAttributesName[]>([]);
  const [attributesValues, setAttributesValues] = useState<any>();
  const [variants , setVariants] = useState<Variants[]>([]);
  const [selectedAttributeName, setSelectedAttributeName] = useState<any>();
  const [selectedAttributeValue, setSelectedAttributeValue] = useState<any>();
  const [showdialog, setShowDialog] = useState<boolean>(false);
  const [selectedProductImages, setSelectedProductImages] = useState<any>([]);
  const {t} = useTranslation();

  const formik = useFormik<ProductDTO>({
    initialValues: new ProductDTO(),
    validateOnChange: true,
    validationSchema: Yup.object({
      title: Yup.string().required("Title is required"),
      quantity: Yup.number().required("Quantity is required"),
      category: Yup.string().required("Category is required"),
      description: Yup.string().required("Description is required"),
      base_price: Yup.number().required("Price is required"),
    }),

    onSubmit: async () => {
      let subProductArray: any[] = [];
      generateCombinations(variants).map((combination: Combination, index: any) => {
          const subProduct = {
              attribute_text_style: combination.combinationText,
              quantity:             formik.values.sub_product[index].quantity ?? 0,
              width:                formik.values.sub_product[index].width ?? 0,
              height:               formik.values.sub_product[index].height ?? 0,
              sku:                  formik.values.sub_product[index].sku ?? 0,
              price:                formik.values.sub_product[index].price ?? 0,
              active:               formik.values.sub_product[index].active ?? 0,
              weight:               formik.values.sub_product[index].weight ?? 0,
              length:               formik.values.sub_product[index].length ?? 0,
              image:                (formik.values.sub_product as any)?.[index].image,
          };

          subProductArray.push(subProduct);
      });

      await createProduct({ ...formik.values, sub_product: subProductArray, variants: variants });
    },
  });

  useEffect(() => {
    getCategories().then((res) => setCategories(res.data.categories));

    getAttributes().then((res) => {
      const mappedAttributes = res.data.attributes?.map((attribute: any) => ({
        value: attribute.id,
        label: attribute.attribute_name,
        values: attribute.values,
      }));

      setAttributes(mappedAttributes || []);
    });

  },[]);

  const handleChangeImages = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = event.target.files;
    if (selectedFiles) {
      const fileArray: File[] = Array.from(selectedFiles);
      const imageObjects = fileArray.map((file) => file);
      formik.setFieldValue('images', imageObjects);
    }
    const files = Array.from(event.target.files as any);
    setSelectedProductImages(files.map((file:any) => URL.createObjectURL(file)));
  }

  useEffect(() => {
    if (selectedAttributeName !== null) {
      const selectedAttribute = attributes.find((attribute: any) => attribute.value === selectedAttributeName);

      const mappedValues: any = selectedAttribute?.values?.map((value: any) => ({
        value: value.id,
        label: value.value,
        relat_name: value.relat_name
      })) || [];

      setAttributesValues(mappedValues);
    }
  }, [selectedAttributeName, attributes]);

  const CompareVarients = () => {
      const existingVariantIndex = variants.findIndex(variant => variant.id === selectedAttributeName);
      const selectedAttribute : any= attributes.find((attribute: any) => attribute.value === selectedAttributeName);
      const attributeName = selectedAttribute ? selectedAttribute.label : '';

      if (existingVariantIndex === -1) {
          const newValue = selectedAttribute?.values.find((value: any) => value.id === selectedAttributeValue);
          const newVariant = {
              id: selectedAttributeName,
              name: attributeName,
              values: newValue ? [newValue] : []
          };

          setVariants(prevVariants => [...prevVariants, newVariant]);
      } else {
          const existingVariant = variants[existingVariantIndex];
          const valueExists = existingVariant.values.some(value => value.id === selectedAttributeValue);
          if (!valueExists) {
              const newValue = selectedAttribute?.values.find((value: any) => value.id === selectedAttributeValue);
              const updatedVariant = {
                  ...existingVariant,
                values: [...existingVariant.values, newValue].filter(Boolean)
              };
              const updatedVariants = [...variants];
              updatedVariants[existingVariantIndex] = updatedVariant;
              setVariants(updatedVariants);
          }
      }
  };

  const generateCombinations = (attributes: any, index = 0, combination: any[] = [], combinations: Combination[] = []): Combination[] => {
      if (index === attributes.length) {
          const combinationText = combination.map((value, i) => attributes[i].values[value].value).join(' / ');

          const namesAndValues = combination.map((value, i) => ({
              nameId: attributes[i].id,
              valueId: attributes[i].values[value].id
          }));

          combinations.push({ combinationText, namesAndValues });
          return combinations;
      }

      attributes[index].values.forEach((_: any, valueIndex: any) => {
          generateCombinations(attributes, index + 1, [...combination, valueIndex], combinations);
      });

      return combinations;
  }

  const removeVariant = (idToRemove: number) => {
    const updatedVariants = variants.filter(variant => {
      const updatedValues = variant.values.filter(value => value.id !== idToRemove);
      variant.values = updatedValues;
      return updatedValues.length > 0;
    });

    setVariants(updatedVariants);
  };

  return (
    <div className={'grid grid-cols-4 my-4'}>
      <Section className="bg-white col-span-4 rounded-md p-3 my-4 flex gap-2 justify-end">
        <Link href="/products">
          <Button label={t("cancel")} severity="danger" outlined size="small" />
        </Link>

        <Button
          type="submit"
          severity="danger"
          size="small"
          label={t('save')}
          onClick={formik?.handleSubmit as any}
        ></Button>
      </Section>

      <Section title={t('basicInfo')} titleClassName="grid gap-1 grid-cols-1 col-span-4 mx-3" className="grid grid-cols-2 col-span-4 my-4 p-4 rounded-md shadow-none bg-white">
        <div className="md:col-span-4 lg:col-span-2 sm:col-span-4 lg:mx-4 md:mx-4">
          <div className="flex flex-col mt-2">
            <label htmlFor="title">{t('title')}</label>
            <InputText
              type="text"
              name="title"
              id="title"
              onChange={formik.handleChange}
              placeholder={t('title')}
              className={`w-full my-2 ${formik.touched.title && "p-invalid"}`}
            />
          </div>

          <div className="flex flex-col mt-2">
            <label htmlFor="sku">{t('sku')}</label>
            <InputText
              type="text"
              name="sku"
              id="sku"
              onChange={formik.handleChange}
              placeholder={t('sku')}
              className={`w-full my-2 ${formik.touched.sku && "p-invalid"}`}
            />
          </div>

          <div className="flex flex-col mt-2">
            <label htmlFor="editor" className="mb-4 block">
              <span>{t('description')}</span>
              <span className="text-red-500">* </span>
              {formik.touched.description && formik.errors.description && (
                <span className="text-red-500">
                  {JSON.stringify(formik.errors.description)}
                </span>
              )}
            </label>
            <Editor
              name="description"
              onTextChange={(e: EditorTextChangeEvent) =>
                formik.setFieldValue("description", e.htmlValue)
              }
              style={{ height: "320px" }}
              className={`w-full ${formik.touched.description && "p-invalid"}`}
            />
          </div>
        </div>

        <div className="md:col-span-4 lg:col-span-2 sm:col-span-4 lg:mx-4 md:mx-4 mt-2">

          <div className="flex flex-col mt-3">
            <label className="w-full">
              <span>{t('price')} </span>
              <span className="text-red-500">* </span>
              {formik.touched.base_price && (
                <span className="text-red-500">
                  {JSON.stringify(formik.errors.base_price)}
                </span>
              )}
            </label>
            <div className="p-inputgroup flex-1">
              <InputNumber
                placeholder={t('price')}
                name="base_price"
                value={formik.values.base_price}
                onChange={(e:any) => formik.setFieldValue("base_price", e.value)}
              />
              <span className="p-inputgroup-addon">$</span>
            </div>
          </div>

          <div className="flex flex-col mt-3">
            <label className="w-full">
              <span>{t('quantity')} </span>
              <span className="text-red-500">* </span>

              {formik.touched.quantity && (
                <span className="text-red-500">
                  {JSON.stringify(formik.errors.quantity)}
                </span>
              )}
            </label>
            <div className="p-inputgroup flex-1">
              <InputNumber
                placeholder={t('quantity')}
                name="quantity"
                value={formik.values.quantity}
                onChange={(e:any) => formik.setFieldValue("quantity", e.value)}
              />
            </div>
          </div>

          <div className="flex flex-col mt-3">
            <label>
              <span>{t('categories')} </span>
              <span className="text-red-500">* </span>
              {formik.touched.category && formik.errors.category && (
                <span className="text-red-500">
                  {JSON.stringify(formik.errors.category)}
                </span>
              )}
            </label>
            <Dropdown
              name="category"
              className="col-span-1"
              value={selectedCategories}
              onChange={(e: any) => {
                setSelectedCategories(e.value);
                formik.setFieldValue("category", e.value.id);
              }}
              options={categories}
              optionLabel="title"
              placeholder={t('categories')}
            />
          </div>

          <div className="flex flex-col mt-3">
            <label>
              <span>{t('weight')} </span>
            </label>
            <InputNumber
                placeholder={t('weight')}
                name="weight"
                value={formik.values.weight}
                onChange={(e:any) => formik.setFieldValue("weight", e.value)}
              />
          </div>

          <div className="flex flex-col mt-3">
            <label>
              <span>{t('length')} </span>
            </label>
            <InputNumber
                placeholder={t('length')}
                name="length"
                value={formik.values.length}
                onChange={(e:any) => formik.setFieldValue("length", e.value)}
              />
          </div>

          <div className="flex flex-col mt-3">
            <label>
              <span>{t('width')} </span>
            </label>
            <InputNumber
                placeholder={t('width')}
                name="width"
                value={formik.values.width}
                onChange={(e:any) => formik.setFieldValue("width", e.value)}
              />
          </div>

          <div className="flex flex-col mt-3">
            <label>
              <span>{t('height')} </span>
            </label>
            <InputNumber
                placeholder={t('height')}
                name="height"
                value={formik.values.height}
                onChange={(e:any) => formik.setFieldValue("height", e.value)}
              />
          </div>
        </div>
      </Section>

      <Section className="grid grid-cols-2 col-span-4 my-4 p-4 rounded-md shadow-none bg-white">
        <div className="grid gap-1 grid-cols-2 col-span-3 m-2">
          <h1 className="col-span-1">{t('variants')}</h1>
          <div className="add-variants flex justify-end col-span-1 w-full">
            <Button severity="danger" label={t('addVariants')} size="small" onClick={() => setShowDialog(true)}  style={{width:'max-content'}}/>
          </div>
        </div>

        {variants.length > 0 ? (
          <div className="grid gap-1 grid-cols-2 col-span-3 m-2 border-1 p-2 rounded border-slate-200">
              <h1 className="col-span-1">
                <i className="pi pi-align-center" />
                <span className='mx-2'>{t('attribuites')}</span>
              </h1>

              <div className="col-span-2 mt-2 card">
                {variants.map(variant => (
                    <div key={variant.id} className="bg-[#ea5455] text-[#FFF] p-2 mt-2 border-1 hover:bg-[#ea5455d9] border-[#ea5455] hover:border-[#ea5455d9] rounded p-0">
                      <span className="">{variant.name}: </span>
                      {variant.values.length > 0 ? (
                        variant.values.map(value => (
                          <Chip
                            className="d-inline mx-2 bg-[#ea5455] border-1 border-slate-200 text-[#FFF]"
                            key={value.id}
                            label={value.value}
                            removable
                            onClick={() => removeVariant(value.id)}
                          />
                        ))
                      ) : (
                        <p>No values available</p>
                      )}
                    </div>
                  ))}
              </div>
            </div>
        ): <></>}

        <div className="flex flex-col gap-3 col-span-2 border-t-2 border-gray-200 pb-2">
          <div className="rounded-md overflow-hidden products-variants-table">
            <Table
              color="primary"
              aria-label="Example static collection table"
              hideHeader={false}
              className="theme-table"
            >

              <TableHeader>
                <TableColumn>{t('name')} </TableColumn>
                <TableColumn>{t('image')}</TableColumn>
                <TableColumn>{t('quantity')}</TableColumn>
                <TableColumn>{t('sku')}</TableColumn>
                <TableColumn>{t('price')}</TableColumn>
                <TableColumn>{t('height')}</TableColumn>
                <TableColumn>{t('width')}</TableColumn>
                <TableColumn>{t('length')}</TableColumn>
                <TableColumn>{t('weight')}</TableColumn>
                <TableColumn>{t('active')}</TableColumn>
              </TableHeader>

              <TableBody>
                {variants.length === 0 ? (
                    <TableRow key={1}>
                        <TableCell aria-colspan={10} colSpan={10} className="text-center">{t('youDontHaveVariantsYet')}</TableCell>
                        <TableCell className="hidden"> </TableCell>
                        <TableCell className="hidden"> </TableCell>
                        <TableCell className="hidden"> </TableCell>
                        <TableCell className="hidden"> </TableCell><TableCell className="hidden"> </TableCell>
                        <TableCell className="hidden"> </TableCell><TableCell className="hidden"> </TableCell>
                        <TableCell className="hidden"> </TableCell><TableCell className="hidden"> </TableCell>
                    </TableRow>
                  ) :
                  (generateCombinations(variants).map((combination :Combination, index :number) => (
                    <TableRow>
                        <TableCell>
                          <InputText disabled value={`${combination.combinationText}`} />
                        </TableCell>

                        <TableCell>
                          <FileUpload
                              name={`sub_product_image_${index}`}
                              containerClass={'file-upload-product-container'}
                              dividClass={'file-upload-product-divdi'}
                              labelClass={'file-upload-product-label'}
                              inputClass={'file-upload-product-input'}
                              onChange={(e :any) => {
                                const file = e.target.files[0];
                                formik.setFieldValue(`sub_product[${index}].image`, file);
                              }}
                          />
                        </TableCell>

                        <TableCell>
                          <InputNumber
                            name={`sub_product[${index}][quantity]`}
                            onValueChange={e => {
                              formik.setFieldValue(`sub_product[${index}].quantity`, e.value);
                            }}
                            placeholder="Quantity"
                            id={`quantity_${index}`}
                          />
                        </TableCell>

                        <TableCell>
                          <InputText
                            name={`sub_product[${index}][sku]`}
                            onChange={e => {
                              formik.setFieldValue(`sub_product[${index}].sku`, e.target.value);
                            }}
                            placeholder="SKU"
                            id={`sku`}
                          />
                        </TableCell>

                        <TableCell>
                          <InputNumber
                            name={`sub_product[${index}][base_price]`}
                            onValueChange={e => {
                              formik.setFieldValue(`sub_product[${index}].price`, e.value);
                            }}
                            placeholder="Price"
                            id={`price`}
                          />
                        </TableCell>

                        <TableCell>
                          <InputNumber
                            name={`sub_product[${index}][height]`}
                            onValueChange={e => {
                              formik.setFieldValue(`sub_product[${index}].height`, e.value);
                            }}
                            placeholder="Height"
                            id={`height`}
                          />
                        </TableCell>

                        <TableCell>
                          <InputNumber
                            name={`sub_product[${index}][width]`}
                            onValueChange={e => {
                              formik.setFieldValue(`sub_product[${index}].width`, e.value);
                            }}
                            placeholder="Width"
                            id={`width`}
                          />
                        </TableCell>

                        <TableCell>
                          <InputNumber
                            name={`sub_product[${index}][length]`}
                            onValueChange={e => {
                              formik.setFieldValue(`sub_product[${index}].length`, e.value);
                            }}
                            placeholder="Length"
                            id={`length`}
                          />
                        </TableCell>

                        <TableCell>
                          <InputNumber
                            name={`sub_product[${index}][weight]`}
                            onValueChange={e => {
                              formik.setFieldValue(`sub_product[${index}].weight`, e.value);
                            }}
                            placeholder="Weight"
                            id={`weight`}
                          />
                        </TableCell>

                        <TableCell>
                            <InputSwitch
                              checked={ formik.values?.sub_product?.[index]?.active ?? false }
                              onChange={e => {
                                formik.setFieldValue(`sub_product[${index}].active`, e.value);
                              }}
                              name={`sub_product[${index}][active]`}
                              id={`active`}
                            />
                        </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </Section>

      <Dialog
          header={t('addVariants')}
          visible={showdialog}
          style={{maxWidth:'800px', minWidth:'600px'}}
          className="md:w-35rem lg:w-35rem"
          onHide={() => {
            setShowDialog(false)
            setSelectedAttributeName([])
            setSelectedAttributeValue([])
          }}
          footer={
            <>
                <div>
                  <Button
                    label={t('add')}
                    severity="info"
                    size="small"
                    onClick={() => CompareVarients()}
                    className="mt-4"
                  ></Button>

                  <Button
                    label={t("cancel")}
                    severity="danger"
                    outlined
                    size="small"
                    onClick={() => {
                      setShowDialog(false)
                      setSelectedAttributeName([])
                      setSelectedAttributeValue([])
                    }}
                    className="mt-4"
                  ></Button>
                </div>
            </>
          }
        >

        <div className="flex flex-col col-span-2 gap-7 variant-row">
          <div className="grid grid-cols-2 gap-4">

            <Dropdown
              value={selectedAttributeName}
              options={attributes}
              onChange={e => setSelectedAttributeName(e.value)}
              placeholder={t(`SelectAttributeName`)}
              className="w-full"
            />

            <Dropdown
              value={selectedAttributeValue}
              options={attributesValues}
              onChange={e => setSelectedAttributeValue(e.value)}
              placeholder={t(`SelectAttributeValue`)}
              className="w-full"
            />
          </div>
        </div>
      </Dialog>

      <Section title={t('gallery')} className="grid grid-cols-1 col-span-4 my-4 p-4 rounded-md shadow-none bg-white">
        <label htmlFor="">{t('image')}</label>
        <FileUpload onChange={handleChangeImages} name="" multiple={true} 
        selectImage={selectedProductImages}
        />
      </Section>
    </div>
  );
}

export default Add;
