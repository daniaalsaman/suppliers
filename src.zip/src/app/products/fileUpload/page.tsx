"use client"
import AlertIcon from '@/components/icons/AlertIcon';
import UploadIcon from '@/components/icons/UploadIcon';
import WarningIcon from '@/components/icons/WarningIcon';
import Section from '@/components/layout/Section'
import { Button, Card, CardBody, CardHeader, Divider, Input, Select, SelectItem } from '@nextui-org/react';
import React, { useState } from 'react'
import { FileUploader } from 'react-drag-drop-files'
import AlertCard from './AlertCard';

type Props = {}

function page({ }: Props) {
    const [file, setFile] = useState(null);

    const handleChange = (file: any) => {
        setFile(file);
    };
    const fileTypes = ["CSV", "PDF", "XML"];

    return (
        <>
            <Section title='Import products by CSV' className='mt-7 flex flex-col gap-3'>
                <Select variant='bordered' size='md' radius='sm' label="Supplier" labelPlacement='outside' placeholder='select supplier'>
                    <SelectItem key="1"></SelectItem>
                </Select>
                <label htmlFor="">Thumbnail Image</label>
                <FileUploader
                    name="file" types={fileTypes}
                    children={
                        <div className='rounded-md border-dashed border-1 p-5 text-center'>
                            <Button isIconOnly className='my-7 bg-gray-200'>
                                <UploadIcon />
                            </Button>
                            <p>Drop files here or click to upload</p>
                        </div>
                    }
                />
            </Section>
            <Section title='Import products by CSV' className='mt-7 flex flex-col gap-3'>
                <Select variant='bordered' size='md' radius='sm' label="Supplier" labelPlacement='outside' placeholder='select supplier'>
                    <SelectItem key="1"></SelectItem>
                </Select>
                <label htmlFor="">Thumbnail Image</label>
                <FileUploader
                    name="file" types={fileTypes}
                    children={
                        <div className='rounded-md border-dashed border-1 p-5 text-center'>
                            <Button isIconOnly className='my-7 bg-gray-200'>
                                <UploadIcon />
                            </Button>
                            <p>Drop files here or click to upload</p>
                        </div>
                    }
                />
                <div className="relative flex items-center flex-nowrap gap-2 overflow-hidden h-10">
                    <Divider className='w-full' />
                    <span className='absolute top-0 start-1/2 bg-white p-2'>OR</span>
                </div>
                <Input
                    type='text'
                    size='sm'
                    placeholder='Paste the XML link here'
                    variant='bordered'
                    endContent={<Button color='primary' size='sm' className='rounded-md h-7'>import</Button>}
                    classNames={{
                        mainWrapper: "p-2 bg-gray-200 rounded-md",
                        inputWrapper: "rounded-md bg-white h-10 pe-1"
                    }}
                />
            </Section>
            <Section title='Match CSV Fields ' className='mt-7 grid grid-cols-2 gap-3' titleClassName='col-span-2'>
                <div className="p-2.5 bg-red-200 rounded-md col-span-2 flex gap-2 text-pink-700 items-center">
                    <AlertIcon /> 14 columns aren't matched in “FileName.extension”
                </div>
                <div className="flex flex-nowrap gap-5 col-span-2">
                    <AlertCard color='red' />
                    <AlertCard color='gray' />
                    <AlertCard color='yellow' />
                    <AlertCard color='green' />
                </div>
            </Section>
        </>

    )
}

export default page
