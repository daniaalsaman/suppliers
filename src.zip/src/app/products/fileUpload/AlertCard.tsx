import WarningIcon from '@/components/icons/WarningIcon'
import { Button, Card, CardBody, CardHeader, Select, SelectItem } from '@nextui-org/react'
import React from 'react'

type Props = {
    color: string
}

const AlertCard = ({ color }: Props) => {
    return (
        <Card radius='sm' shadow='none' className='w-56'>
            <CardHeader className={`bg-${color}-500 rounded-b-md text-white flex flex-col items-center p-0`}>
                <div className="flex items-center p-2 gap-2">
                    <WarningIcon /> Unmatched column
                </div>
                <div className={`bg-${color}-200 w-full p-3 rounded-md border-1 border-${color}-500`}>
                    <Select className='text-gray-400' classNames={{
                        trigger: "bg-white",
                        selectorIcon: "text-gray-400"
                    }} variant='bordered' size='md' radius='sm' label="Import “Category” as" labelPlacement='outside' placeholder='select option'>
                        <SelectItem key="1"></SelectItem>
                    </Select>
                </div>
            </CardHeader>
            <CardBody className='border-1 border-gray-200 -mt-1 rounded-b-lg'>
                <div className="bg-gray-50 rounded-md">
                    <p className='border-b-1 border-gray-200 p-2'>Fashion</p>
                    <p className='border-b-1 border-gray-200 p-2'>Fashion</p>
                    <p className='border-gray-200 p-2 border-b-none'>Fashion</p>
                </div>
                <Button className='bg-gray-200 rounded-md mt-3' size='sm'>
                    Dont Import
                </Button>
            </CardBody>
        </Card>
    )
}

export default AlertCard