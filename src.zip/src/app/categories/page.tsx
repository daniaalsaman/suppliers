"use client";
import React, { useEffect, useState } from "react";
import Link from "next/link";
import { getCategories, getProductList } from "../../Api/Services";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { InputSwitch } from "primereact/inputswitch";
import { Paginator } from "primereact/paginator";
import { useTranslation } from "react-i18next";

interface Category {
  id: string;
  title: string;
  description: string;
  appears_on_suggestions: string;
  parent_id: string;
  level: number;
  commission: number;
}

export default function Categories() {
  const [categories, setCategories] = useState<Category[]>();
  const {t, i18n} = useTranslation()

  useEffect(() => {
    getCategories().then((e: any) => {
      setCategories(e.data.categories);
    });
  }, []);

  const switchTemplate = (category: any) => {
    let status = category.appears_on_suggestions;

    const [checked, setChecked] = useState(status === 1 ? true : false);

    return (
      <div className="card flex justify-content-center">
        <InputSwitch
          disabled
          checked={checked}
          onChange={(e: any) => setChecked(e.value)}
          className="w-12 h-7 "
        />
      </div>
    );
  };
  const formatParent = (category: any) => {
    let catParent = category.parent_id;
    if (catParent == null) {
      return "-";
    } else {
      return `${catParent}`;
    }
  };

  const [visible, setVisible] = useState(false);

  const [deleting, setDeleting] = useState(false);
  const accept = async (category: any) => {
    setDeleting(true);
    // await deletecatagory

    setDeleting(false);
    setVisible(false);
  };

  const reject = () => {
    setVisible(false);
  };


  return (
    <>
      <DataTable
        value={categories}
        paginator
        rows={5}
        rowsPerPageOptions={[5, 10, 25, 50]}
        size="normal"
        dataKey="id"
        className="mt-6"
      >
        <Column
          sortable
          field="title"
          header={t('name')}
          style={{ width: "10%" }}
        ></Column>
        <Column
          field="description"
          header={t('description')}
          style={{ width: "32%" }}
        ></Column>
        <Column
          field="appears_on_suggestions"
          header={t('status')}
          body={switchTemplate}
          style={{ width: "12%" }}
        ></Column>
        <Column field="level" header={t('level')} style={{ width: "10%" }}></Column>
        <Column
          sortable
          field="commission"
          header={t('commission')}
          style={{ width: "10%" }}
        ></Column>
      </DataTable>
    </>
  );
}
