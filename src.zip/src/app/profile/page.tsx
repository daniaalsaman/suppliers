"use client";
import { useEffect, useState } from "react";
import { useFormik } from "formik";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Panel } from "primereact/panel";
import { Button } from "primereact/button";
import { ConfirmDialog, confirmDialog } from "primereact/confirmdialog";
import { UserDTO } from "@/modules/supplier.modules";
import {
  UpdateXMLProduct,
  deleteUser,
  editUser,
  getCities,
  getCountries,
  getMnicipalities,
  getNeighborhoods,
  userInfo,
} from "@/Api/Services";
import FileUpload from "@/components/FileUploader";
import { InputNumber } from "primereact/inputnumber";
import { useTranslation } from "react-i18next";
import { Dialog } from "primereact/dialog";
import ResetPassword from "../resetPassword/page";
import { FileUploader } from "react-drag-drop-files";

const Profile = () => {
  const [Country, setCountry] = useState<any>();
  const [City, setCity] = useState<any>();
  const [Municipality, setMunicipality] = useState<any>();
  const [Neighborhood, setNeighborhood] = useState<any>();
  const [show, setshow] = useState<boolean>(false);
  const [file, setFile] = useState<any>();
  const [cover, setCover] = useState<any>();
  const [showPass, setShowPass] = useState<boolean>(false);
  const [selectedLogoImages, setSelectedLogoImages] = useState<any>([]);
  const [selectedCoverImages, setSelectedCoverImages] = useState<any>([]);

  const { t } = useTranslation();

  const Profileform = useFormik<UserDTO>({
    initialValues: new UserDTO(),
    validateOnChange: true,
    onSubmit: () => {
      const formData = new FormData();
      {
        if (cover !== undefined) {
          formData.append("supplier_cover", cover);
        }
      }
      {
        if (file !== undefined) {
          formData.append("supplier_logo", file);
        }
      }
      formData.append("countries", Profileform.values.address?.country?.id);
      formData.append("cities", Profileform.values.address?.city?.id);
      formData.append(
        "municipalities",
        Profileform.values.address?.municipality?.id
      );
      {
        if (Profileform.values.address?.neighborhood?.id !== undefined) {
          formData.append(
            "neighborhoods",
            Profileform.values.address?.neighborhood?.id
          );
        }
      }
      formData.append("street", Profileform.values.address?.street);
      formData.append("apartment", Profileform.values.address?.apartment);
      formData.append("floor", Profileform.values.address?.floor);
      formData.append("building", Profileform.values.address?.building);
      formData.append("supplier_name", Profileform.values.supplier?.name);
      formData.append("email", Profileform.values.email);
      formData.append("first_name", Profileform.values.first_name);
      formData.append("last_name", Profileform.values.last_name);
      formData.append(
        "supplier_commission",
        Profileform.values.supplier?.commission as any
      );
      formData.append(
        "supplier_contact_number",
        Profileform.values.supplier?.contact_number
      );
      formData.append("status", "ACTIVE");

      editUser(formData);
    },
  });
  const GetUserdata = () => {
    userInfo().then((res: any) => {
      Profileform?.setValues(res ? res.data : null);
      console.log(res.data.address.country.id)
      getCities(res.data?.address?.country?.id).then((res) => setCity(res.data));
     getMnicipalities(res.data?.address?.city?.id).then((res) => setMunicipality(res.data))
    });

    getCountries().then((res) => setCountry(res.data));

  };

  useEffect(() => {
    GetUserdata();
  }, []);

  const onCountryChange = async (e: any) => {
    const value = e.target.value as number;
    Profileform.setFieldValue("address.country.id", value);
    setshow(true);
    await getCities(e.target.value).then((res) => setCity(res.data));
  };

  const onCityChange = async (e: any) => {
    const value = e.target.value as number;
    Profileform.setFieldValue("address.city.id", value);
    await getMnicipalities(e.target.value).then((res) =>
      setMunicipality(res.data)
    );
  };

  const onMunicipalityChange = async (e: any) => {
    const value = e.target.value as number;
    Profileform.setFieldValue("address.municipality.id", value);
    await getNeighborhoods(e.target.value).then((res) =>
      setNeighborhood(res.data)
    );
  };

  const onNeighborhoodChange = (e: any) => {
    const value = e.target.value as number;
    Profileform.setFieldValue("address.neighborhood.id", value);
  };

  const UpdateXML = (id: number) => {
    let data = {
      xml_id: id,
    };

    UpdateXMLProduct(data);
  };

  const confirm = () => {
    confirmDialog({
      message: t("deleteaccountmsg"),
      header: t("deleteconfirm"),
      icon: "pi pi-info-circle",
      defaultFocus: "reject",
      acceptClassName: "p-button-danger py-2",
      rejectClassName: "p-button-outlined py-2",
      acceptLabel: t("delete"),
      rejectLabel: t("cancel"),
      accept: () => deleteUser(),
    });
  };

  function handleChange(event: any) {
    setFile(event.target.files[0]);
    const files = Array.from(event.target.files);
    setSelectedLogoImages(files.map((file:any) => URL.createObjectURL(file)));
  }

  function handleCoverChange(event: any) {
    setCover(event.target.files[0]);
    const files = Array.from(event.target.files);
      setSelectedCoverImages(files.map((file:any) => URL.createObjectURL(file)));
  }
  const imports = Profileform?.values?.data?.supplier;
  const csvFiles = imports?.csv_files || [];
  const xmlFiles = imports?.xml_urls || [];

  const renderCSVFiles = () => {
    if (csvFiles.length === 0) {
      return <div>No CSV files available</div>;
    }

    return csvFiles.map((file: any, index: number) => (
      <div className={`${index > 0 ? "mt-5" : ""}`}>
        <label className="mb-2" htmlFor="CSV File">
          - CSV File, <span style={{ color: "red" }}>{file?.size} M</span>
        </label>
        <div>
          <InputText
            disabled
            placeholder="CSV Name"
            value={file.name}
            className="w-full"
          />
        </div>
      </div>
    ));
  };

  const renderXMLFiles = () => {
    if (xmlFiles.length === 0) {
      return <div>No XML files available</div>;
    }

    return xmlFiles.map((file: any, index: number) => (
      <div className={`${index > 0 ? "mt-5" : ""}`}>
        <label className="mb-2" htmlFor="XML Files">
          - XML File{" "}
          <i
            className="pi pi-sync mx-2 !text-sm"
            style={
              file.can_update === false
                ? { fontSize: "1.2rem", cursor: "pointer", color: "gray" }
                : { fontSize: "1.2rem", cursor: "pointer", color: "green" }
            }
            onClick={() =>
              file.can_update === false ? () => {} : UpdateXML(file?.id)
            }
          ></i>
        </label>
        <div>
          <p className="p-2" style={{ color: "black" }}>
            {file?.message}
          </p>
        </div>
        <div>
          <InputText
            disabled
            placeholder="XML Name"
            value={file.url}
            className="w-full"
          />
        </div>
      </div>
    ));
  };

  return (
    <div>
      <ConfirmDialog />
      <Dialog
        header={t("resetPassword")}
        visible={showPass}
        style={{ width: "50vw" }}
        onHide={() => setShowPass(false)}
      >
        <ResetPassword />
      </Dialog>

      <div className="w-full mt-4 p-3">
        <div className="flex justify-end align-center items-center border-t-[5px] rounded border-slate-200 mb-4 bg-white py-3 px-5">
          <Button
            className="mb-2 mr-3"
            severity="danger"
            label={t("updateProfile")}
            outlined
            icon="pi pi-check"
            iconPos={"left"}
            onClick={() => Profileform.handleSubmit()}
          />
          <Button
            className="mb-2 mr-3"
            label={t("deleteAccounr")}
            severity="danger"
            icon="pi pi-times"
            iconPos={"left"}
            onClick={confirm}
          />
          <Button
            className="mb-2"
            label={t("resetPassword")}
            severity="info"
            outlined
            icon="pi pi-key"
            iconPos={"left"}
            onClick={() => setShowPass(true)}
          />
        </div>

        <Panel header={t("PersonalInformation")}>
          <div className="grid grid-cols-3 col-span-4 gap-1">
            <div className="mx-2">
              <label className="mb-2" htmlFor="Firstname">
                {" "}
                {t("firstname")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("firstname")}
                  value={Profileform.values?.first_name}
                  onChange={Profileform.handleChange}
                  name="first_name"
                  className="w-full"
                />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="Lastname">
                {" "}
                {t("lastname")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("lastname")}
                  value={Profileform.values.last_name}
                  onChange={Profileform.handleChange}
                  name="last_name"
                  className="w-full"
                />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="Email">
                {" "}
                {t("email")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("email")}
                  value={Profileform.values.email}
                  onChange={Profileform.handleChange}
                  name="email"
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </Panel>

        <Panel header={t("addressinformation")} className="mt-4">
          <div className="grid grid-cols-3 col-span-4 gap-1">
            <div className="mx-2">
              <label className="mb-2" htmlFor="Country">
                {" "}
                {t("selectCountry")}{" "}
              </label>
              <div>
                <Dropdown
                  value={Profileform.values.address?.country?.id}
                  onChange={onCountryChange}
                  name="country"
                  options={Country}
                  optionValue="id"
                  optionLabel="name"
                  placeholder={t("selectCountry")}
                  className="w-full"
                />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="City">
                {" "}
                {t("selectCity")}{" "}
              </label>
              <div>
                
                  <Dropdown
                    key={JSON.stringify(City)}
                    value={Profileform.values.address?.city?.id}
                    onChange={onCityChange}
                    name="city"
                    options={City}
                    optionValue="id"
                    optionLabel="name"
                    placeholder={t("selectCity")}
                    className="w-full"
                  />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="Municipality">
                {" "}
                {t("selectMunicipality")}{" "}
              </label>
              <div>
                  <Dropdown
                    value={Profileform.values.address?.municipality?.id}
                    onChange={onMunicipalityChange}
                    name="municipality"
                    options={Municipality}
                    optionValue="id"
                    optionLabel="name"
                    placeholder={t("selectMunicipality")}
                    className="w-full"
                  />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 col-span-4 gap-1 mt-4">
            <div className="mx-2">
              <label className="mb-2" htmlFor="Neighborhood">
                {" "}
                {t("selectNeighborhood")}{" "}
              </label>
              <div>
                <Dropdown
                  value={Profileform.values.address?.neighborhood?.id}
                  onChange={onNeighborhoodChange}
                  name="neighborhood"
                  options={Neighborhood}
                  optionValue="id"
                  optionLabel="name"
                  className="w-full"
                  placeholder={t("selectNeighborhood")}
                />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="building">
                {" "}
                {t("building")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("building")}
                  value={Profileform.values.address?.building}
                  onChange={(e) =>
                    Profileform.setFieldValue(
                      "address.building",
                      e.target.value
                    )
                  }
                  name="building"
                  className="w-full"
                />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="Floor">
                {" "}
                {t("floor")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("floor")}
                  value={Profileform.values.address?.floor}
                  onChange={(e) =>
                    Profileform.setFieldValue("address.floor", e.target.value)
                  }
                  name="floor"
                  className="w-full"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 col-span-4 gap-1 mt-4">
            <div className="mx-2">
              <label className="mb-2" htmlFor="street">
                {" "}
                {t("street")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("street")}
                  value={Profileform.values.address?.street}
                  onChange={(e) =>
                    Profileform.setFieldValue("address.street", e.target.value)
                  }
                  name="street"
                  className="w-full"
                />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="Apartment">
                {" "}
                {t("apartment")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("apartment")}
                  value={Profileform.values.address?.apartment}
                  onChange={(e) =>
                    Profileform.setFieldValue(
                      "address.apartment",
                      e.target.value
                    )
                  }
                  name="apartment"
                  className="w-full"
                />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="Details">
                {" "}
                {t("details")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("details")}
                  value={Profileform.values.address?.more_details}
                  onChange={Profileform.handleChange}
                  name="more_details"
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </Panel>

        <Panel header={t("supplierInformation")} className="mt-4">
          <div className="grid grid-cols-3 col-span-4 gap-1">
            <div className="mx-2">
              <label className="mb-2" htmlFor="name">
                {" "}
                {t("name")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("name")}
                  value={Profileform.values.supplier?.name}
                  onChange={(e) =>
                    Profileform.setFieldValue("supplier.name", e.target.value)
                  }
                  name="supplier.name"
                  className="w-full"
                />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="contactnumber">
                {" "}
                {t("contactNumber")}{" "}
              </label>
              <div>
                <InputText
                  placeholder={t("contactNumber")}
                  value={Profileform.values.supplier?.contact_number}
                  onChange={(e) =>
                    Profileform.setFieldValue(
                      "supplier.contact_number",
                      e.target.value
                    )
                  }
                  name="supplier.contact_number"
                  className="w-full"
                />
              </div>
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="commission">
                {" "}
                {t("commission")}{" "}
              </label>
              <div>
                <InputNumber
                  placeholder={t("commission")}
                  value={Profileform.values.supplier?.commission}
                  onChange={(e) =>
                    Profileform.setFieldValue("supplier.commission", e.value)
                  }
                  name="supplier.commission"
                  className="w-full"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 col-span-4 gap-1 mt-4">
            <div className="mx-2">
              <label className="mb-2" htmlFor="contactnumber">
                {" "}
                {t("logo")}{" "}
              </label>
              <FileUpload
                path={Profileform.values.supplier?.logo as any}
                onChange={handleChange}
                name=""
                selectImage={selectedLogoImages}
              />
            </div>

            <div className="mx-2">
              <label className="mb-2" htmlFor="contactnumber">
                {" "}
                {t("cover")}{" "}
              </label>
              <FileUpload
                path={Profileform.values.supplier?.cover as any}
                onChange={handleCoverChange}
                name=""
                selectImage={selectedCoverImages}
              />
              {/* <FileUploader handleChange={handleCoverChange}   /> */}
            </div>
          </div>
        </Panel>

        <Panel header={t("supplierLinks")} className="mt-4">
          <div className="grid grid-cols-2 col-span-4 gap-1">
            <div className="p-2 mt-3 border-l-3 border-slate-200">
              {renderCSVFiles()}
            </div>
            <div className="p-2 mt-3 border-l-3 border-slate-200">
              {renderXMLFiles()}
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
};

export default Profile;
