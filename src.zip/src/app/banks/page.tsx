"use client"
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import { useFormik } from "formik";
import { InputNumber } from "primereact/inputnumber";
import { InputText } from "primereact/inputtext";
import { InputSwitch } from "primereact/inputswitch";
import { ConfirmDialog, confirmDialog } from "primereact/confirmdialog";
import { Dropdown } from "primereact/dropdown";
import { BanksInfo, CurrencySystem, CreateBankAccount, UpdateBankAccount, DetailsBankAccount, DeleteBankAccount } from "@/Api/Services";
import { BankDTO } from "@/modules/supplier.modules";
import { useTranslation } from "react-i18next";
import { CREATE_BANK_ACCOUNT, DELETE_BANK_ACCOUNTS, UPDATE_BANK_ACCOUNTS } from "@/permissions/permissions";
import { FilterMatchMode } from "primereact/api";

const Banks = () => {
  const [BankList, setBankList] = useState<any>();
  const [show, setShow] = useState<boolean>(false);
  const [showEdit, setShowEdit] = useState<boolean>(false);
  const [rowIdForEdit, setRowIdForEdit] = useState<number>();
  const [CurrencyList, setCurrencyList] = useState<any>();
  const [propEmpty, setPropEmpty] = useState<any>();
  const {t, i18n} = useTranslation()
  const [globalFilterValue, setGlobalFilterValue] = useState("");
  const [filters, setFilters] = useState({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    account_holder_name: {
      value: null,
      matchMode: FilterMatchMode.STARTS_WITH,
    },
    account_number: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    account_type: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    balance: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    bank_name: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    branch_name: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    created_at: { value: null, matchMode: FilterMatchMode.DATE_IS },
    currency: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    swift_code: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
  });
  const getBanks = () => {
    BanksInfo().then((res) => {
      if (res !== undefined ){
      if ("image" in res && "message" in res) {
        setPropEmpty(res);
      } else {
        setBankList(res.data);
      }}
    });
    CurrencySystem().then((res) => setCurrencyList(res.data));
  };
  const options = CurrencyList?.map((currency: any) => ({
    label: currency,
    value: currency,
  }));
  const Bankform = useFormik<BankDTO>({
    initialValues: new BankDTO(),
    validateOnChange: true,
    onSubmit: () => {
      CreateBankAccount(Bankform.values);
      setShow(false);
    },
  });

  const BankformEdit = useFormik<BankDTO>({
    initialValues: new BankDTO(),
    validateOnChange: true,
    onSubmit: () => {
      UpdateBankAccount(BankformEdit.values, rowIdForEdit);
      setShowEdit(false);
    },
  });

  const ShowBank = async (id: number) => {
    setShowEdit(true);
    const data = await DetailsBankAccount(id);
    BankformEdit.setValues(data?.data);
    setRowIdForEdit(id);
  };
  useEffect(() => {
    getBanks();
  }, []);
  const DeleteAccount = (id: number) => {
    DeleteBankAccount(id);
  };
  const confirm = (id: number) => {
    confirmDialog({
      message: t('deleteaccountmsg'),
      header: t('deleteconfirm'),
      icon: "pi pi-info-circle",
      defaultFocus: "reject",
      acceptClassName: "p-button-danger py-2",
      rejectClassName: "p-button-outlined py-2",
      acceptLabel: t('delete'),
      rejectLabel: t('cancel'),
      accept: () => DeleteAccount(id),
    });
  };

  const onGlobalFilterChange = (e: any) => {
    const value = e.target.value;
    let _filters = { ...filters };

    _filters["global"].value = value;

    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  const renderHeader = () => {
    return (
      <div className="flex flex-wrap gap-3 align-items-center">
  {CREATE_BANK_ACCOUNT() && (
    <Button
      label={t('addNewBank')}
      onClick={() => setShow(true)}
      size="small"
      severity="danger"
      className="mt-4"
    />
  )}
  <span className="p-input-icon-left m-2" style={{ marginLeft: 'auto' }}>
    <InputText
      value={globalFilterValue}
      onChange={onGlobalFilterChange}
      placeholder={t('search')}
      />
  </span>
</div>

    );
  };
  const header = renderHeader();

  const BodyTemplate = (rowData: any) => {
    return (
      <div className="gap-3">
       { UPDATE_BANK_ACCOUNTS() ? <i
          className="pi pi-bold pi-pencil"
          onClick={() => ShowBank(rowData?.id)}
          style={{
            fontSize: "1.2rem",
            color: "slateblue",
            padding: "7px",
            cursor: "pointer",
          }}
        ></i> :<></>}
        {DELETE_BANK_ACCOUNTS()? <i
          className="pi pi-bold pi-trash"
          onClick={() => confirm(rowData?.id)}
          style={{ fontSize: "1.2rem", color: "red", cursor: "pointer" }}
        ></i> : <></>}
      </div>
    );
  };
  return (
    
    <div>
      <ConfirmDialog />
      <DataTable
        value={BankList}
        stripedRows
        showGridlines
        className=" p-5"
        tableStyle={{ minWidth: "50rem" }}
        header={header}
        filters={filters}
        emptyMessage={t('tableMsg')}
      >
        <Column field="account_holder_name" header={t('accountName')}></Column>
        <Column field="account_number" header={t('accountNumber')}></Column>
        <Column field="account_type" header={t('accountType')}></Column>
        <Column field="balance" header={t('balance')}></Column>
        <Column field="bank_name" header={t('bankName')}></Column>
        <Column field="branch_name" header={t('branchName')}></Column>
        <Column field="created_at" header={t('date')}></Column>
        <Column field="currency" header={t('currency')}></Column>
        <Column field="iban" header={t('IBAN')}></Column>
        <Column field="swift_code" header={t('swiftCode')}></Column>
        <Column field="" header={t('actions')} body={BodyTemplate}></Column>
      </DataTable>
      <></>
      <Dialog
        header={t('addNewBank')}
        visible={show}
        style={{ width: "50vw" }}
        onHide={() => setShow(false)}
        footer={
          <>
            <div>
              <Button
                label={t('save')}
                severity="info"
                size="small"
                onClick={() => Bankform.handleSubmit()}
                className="mt-4"
              ></Button>
              <Button
                label={t('cancel')}
                severity="danger"
                outlined
                size="small"
                onClick={() => setShow(false)}
                className="mt-4"
              ></Button>
            </div>
          </>
        }
      >
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div >
            <div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('accountNumber')}{" "}
            </label>
            </div>
            <InputText
              placeholder={t('accountNumber')}
              name="account_number"
              value={Bankform?.values?.account_number}
              onChange={(e) =>
                Bankform.setFieldValue("account_number", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4">
            <div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('bankName')}{" "}
            </label>
            </div>
            <InputText
              placeholder={t('bankName')}
              name="bank_name"
              value={Bankform?.values?.bank_name}
              onChange={(e) =>
                Bankform.setFieldValue("bank_name", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4">
            <div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('accountHolderName')}{" "}
            </label>
            </div>
            <InputText
              placeholder={t('accountHolderName')}
              name="account_holder_name"
              value={Bankform?.values?.account_holder_name}
              onChange={(e) =>
                Bankform.setFieldValue("account_holder_name", e.target.value)
              }
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
          <div >
            <div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('accountType')}{" "}
            </label>
            </div>
            <InputText
              placeholder={t('accountType')}
              name="account_type"
              value={Bankform?.values?.account_type}
              onChange={(e) =>
                Bankform.setFieldValue("account_type", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4">
            <div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('branchName')}{" "}
            </label>
            </div>
            <InputText
              placeholder={t('branchName')}
              name="branch_name"
              value={Bankform?.values?.branch_name}
              onChange={(e) =>
                Bankform.setFieldValue("branch_name", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4">
            <div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('IBAN')}{" "}
            </label>
            </div>
            <InputText
              placeholder={t('IBAN')}
              name="iban"
              value={Bankform?.values?.iban}
              onChange={(e) => Bankform.setFieldValue("iban", e.target.value)}
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
          <div>
            <div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('IFSC')}{" "}
            </label>
            </div>
            <InputText
              placeholder= {t('IFSC')}
              name="ifsc_code"
              value={Bankform?.values?.ifsc_code}
              onChange={(e) =>
                Bankform.setFieldValue("ifsc_code", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4">
            <div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('swiftCode')}{" "}
            </label>
            </div>
            <InputText
              placeholder={t('swiftCode')}
              name="swift_code"
              value={Bankform?.values?.swift_code}
              onChange={(e) =>
                Bankform.setFieldValue("swift_code", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4">
            <div>
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('currency')}{" "}
            </label>
            </div>
            <Dropdown
              value={Bankform?.values?.currency}
              onChange={(e) =>
                Bankform.setFieldValue("currency", e.target.value)
              }
              options={options}
              optionLabel="label"
              optionValue="value"
              name="currency"
              placeholder={t('currency')}
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
          <div>
            <div>
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('balance')}{" "}
            </label>
            </div>
            <InputNumber
              placeholder={t('balance')}
              name="balance"
              value={Bankform?.values?.balance}
              onChange={(e) => Bankform.setFieldValue("balance", e.value)}
              className="w-full"
            />
          </div>
          <div className="md:col-4 lg:col-4 mt-3">
            <div>
            <label className="" htmlFor="Wallet">
              {" "}
              {t('primary')}{" "}
            </label>
            </div>
            <InputSwitch
              name="is_primary"
              checked={Bankform?.values?.is_primary}
              onChange={(e) => Bankform.setFieldValue("is_primary", e.value)}
            />          
          </div>
        </div>
      </Dialog>
      <></>
      <Dialog
        header={t('editBank')}
        visible={showEdit}
        style={{ width: "50vw" }}
        onHide={() => setShowEdit(false)}
        footer={
          <>
            <div>
              <Button
                label={t('save')}
                severity="info"
                size="small"
                onClick={() => BankformEdit.handleSubmit()}
                className="mt-4"
              ></Button>
              <Button
                label={t('cancel')}
                severity="danger"
                outlined
                size="small"
                onClick={() => setShowEdit(false)}
                className="mt-4"
              ></Button>
            </div>
          </>
        }
      >
        <div className="grid grid-cols-3 gap-4">
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('accountNumber')}{" "}
            </label>
            <InputText
              placeholder={t('accountNumber')}
              name="account_number"
              value={BankformEdit?.values?.account_number}
              onChange={(e) =>
                BankformEdit.setFieldValue("account_number", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('bankName')}{" "}
            </label>
            <InputText
              placeholder={t('bankName')}
              name="bank_name"
              value={BankformEdit?.values?.bank_name}
              onChange={(e) =>
                BankformEdit.setFieldValue("bank_name", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('accountHolderName')}{" "}
            </label>
            <InputText
              placeholder={t('accountHolderName')}
              name="account_holder_name"
              value={BankformEdit?.values?.account_holder_name}
              onChange={(e) =>
                BankformEdit.setFieldValue(
                  "account_holder_name",
                  e.target.value
                )
              }
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4 mt-4">
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('accountType')}{" "}
            </label>
            <InputText
              placeholder={t('accountType')}
              name="account_type"
              value={BankformEdit?.values?.account_type}
              onChange={(e) =>
                BankformEdit.setFieldValue("account_type", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('branchName')}{" "}
            </label>
            <InputText
              placeholder={t('branchName')}
              name="branch_name"
              value={BankformEdit?.values?.branch_name}
              onChange={(e) =>
                BankformEdit.setFieldValue("branch_name", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('IBAN')}{" "}
            </label>
            <InputText
              placeholder={t('IBAN')}
              name="iban"
              value={BankformEdit?.values?.iban}
              onChange={(e) =>
                BankformEdit.setFieldValue("iban", e.target.value)
              }
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4 mt-4">
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('IFSC')}{" "}
            </label>
            <InputText
              placeholder={t('IFSC')}
              name="ifsc_code"
              value={BankformEdit?.values?.ifsc_code}
              onChange={(e) =>
                BankformEdit.setFieldValue("ifsc_code", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('swiftCode')}{" "}
            </label>
            <InputText
              placeholder={t('swiftCode')}
              name="swift_code"
              value={BankformEdit?.values?.swift_code}
              onChange={(e) =>
                BankformEdit.setFieldValue("swift_code", e.target.value)
              }
              className="w-full"
            />
          </div>
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('currency')}{" "}
            </label>
            <InputText
              placeholder={t('currency')}
              name="currency"
              value={BankformEdit?.values?.currency}
              onChange={(e) =>
                BankformEdit.setFieldValue("currency", e.target.value)
              }
              className="w-full"
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 mt-4">
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Status">
              {" "}
              {t('balance')}{" "}
            </label>
            <InputNumber
              placeholder={t('balance')}
              name="balance"
              value={BankformEdit?.values?.balance}
              onChange={(e) => BankformEdit.setFieldValue("balance", e.value)}
              className="w-full"
            />
          </div>
          <div className="grid grid-flow-row-dense ">
            <label className="mb-2" htmlFor="Wallet">
              {" "}
              {t('primary')}{" "}
            </label>
            <InputSwitch
              name="is_primary"
              checked={BankformEdit?.values?.is_primary}
              onChange={(e) =>
                BankformEdit.setFieldValue("is_primary", e.value)
              }
            />
          </div>
        </div>
      </Dialog>
    </div>
  );
};

export default Banks;
