import Section from '@/components/layout/Section'
import React from 'react'

type Props = {}

const page = (props: Props) => {
  return (
    <Section>
        
    </Section>
  )
}

export default page