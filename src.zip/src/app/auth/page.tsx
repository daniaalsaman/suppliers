import React from "react";
import { Tabs, Tab, Card, CardBody } from "@nextui-org/react";
import LoginPage from "@/components/LoginPage";

export default function Login() {
    
    return (
        <LoginPage />
    );
}
