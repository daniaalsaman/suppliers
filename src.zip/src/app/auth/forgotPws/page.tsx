"use client"
import { Button, Input } from '@nextui-org/react';
import React, { useState } from 'react';
import * as Yup from 'yup';
import { useFormik } from 'formik';

function ForgotPws() {
    const [isSignUpActive, setIsSignUpActive] = useState(false);
    const [isVisible, setIsVisible] = React.useState(false);

    const toggleVisibility = () => setIsVisible(!isVisible);
    const validationSchema = Yup.object({
        name: Yup.string().required('Name is required'),
        email: Yup.string().email('Invalid email format').required('Email is required'),
        password: Yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
    });

    const register = useFormik({
        initialValues: {
            name: '',
            email: '',
            password: '',
        },
        validationSchema,
        onSubmit: (values) => {
        },
    });

    const login = useFormik({
        initialValues: {
            email: '',
            password: '',
        },
        validationSchema,
        onSubmit: (values) => {
        },
    });
    const togglePanel = () => {
        setIsSignUpActive(!isSignUpActive);
    };

    return (
        <div className="loginPage">
            <div className="App">
                <div id="container" className={`container ${isSignUpActive ? 'right-panel-active' : ''}`}>
                    <div className="form-container !opacity-100 !w-full sign-up-container block translate-x-0 ">
                        <form className='!opacity-100' onSubmit={register.handleSubmit}>
                            <h1>Forgot Password</h1>
                            <Input
                                type="email"
                                radius='sm'
                                size='sm'
                                variant='bordered'
                                classNames={{
                                    base:"w-1/2",
                                    errorMessage: "text-start"
                                }}
                                placeholder="Email"
                                defaultValue={register.values.email}
                                isInvalid={register.touched.email}
                                errorMessage={register.errors.email}
                                onChange={register.handleChange}
                            />
                            <Button type='submit'>Send</Button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ForgotPws;
